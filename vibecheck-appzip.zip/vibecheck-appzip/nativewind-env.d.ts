/* eslint-disable */
/// <reference types="nativewind/types" />
declare module "*.css";
