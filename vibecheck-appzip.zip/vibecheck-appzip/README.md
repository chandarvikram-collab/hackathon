# VibeCheck

Proximity-based professional & social networking app. Built with React Native
(Expo Router) + Supabase, following the VibeCheck PRD.

## What's implemented

- **Auth** — email/password sign up & sign in (Supabase Auth)
- **4-step onboarding wizard** — Basics, Growth & Ambition, Collaboration Style, Icebreakers
- **Discovery screen** — Map view (translucent teal proximity circles, not pins) and List view, toggle between them
- **Profile Drawer** — bottom sheet with the animated VibeMatch Bar, skill chips, and icebreaker blockquotes
- **VibeMatch scoring** — computed **server-side** via a Postgres RPC function, never in client JS
- **Location privacy** — exact GPS coordinates never leave the device except to a Supabase Edge Function over HTTPS; a randomized 100–500m offset is computed and stored server-side, and the client only ever reads `approx_latitude`/`approx_longitude` from a view that structurally excludes the exact columns
- **Connections** — send/accept/decline requests, with a Messages tab listing accepted connections

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Create your Supabase project

If you don't have one yet: [supabase.com](https://supabase.com) → New Project.

### 3. Configure environment variables

```bash
cp .env.example .env
```

Open `.env` and fill in your project's URL and anon key (Supabase Dashboard →
Project Settings → API).

### 4. Run the database migrations

In the Supabase SQL Editor, run the two files in `supabase/migrations/` **in
order**:

1. `0001_init.sql` — tables, the `public_profiles` view, and RLS policies
2. `0002_match_score.sql` — the `get_match_score` RPC function

Or, if you have the Supabase CLI linked to your project:

```bash
supabase db push
```

### 5. Deploy the location edge function

```bash
supabase functions deploy update_location
```

This function is what actually enforces the location-privacy model — it's
the only thing allowed to write `exact_latitude`/`exact_longitude` and
compute the randomized `approx_*` offset. See the comments in
`supabase/functions/update_location/index.ts` for why this can't live on
the client.

### 6. Start the app

```bash
npx expo start
```

Scan the QR code with Expo Go, or press `i` / `a` for an iOS/Android
simulator. **Maps require a physical device or a simulator with Google
Play Services / Apple Maps configured** — `react-native-maps` doesn't
render in Expo Go on every platform without extra config; see
[the react-native-maps docs](https://github.com/react-native-maps/react-native-maps)
if the map view comes up blank.

## Project structure

```
app/                      Expo Router screens
  (auth)/                 sign-in, sign-up
  onboarding/              step-1 .. step-4 (shared draft via OnboardingProvider)
  (tabs)/                  discover, messages, profile
  _layout.tsx             root layout — auth/profile routing logic lives here
src/
  components/             ChipSelector, VibeMatchBar, ProfileDrawer, etc.
  hooks/                  useAuth, useNearbyProfiles, useMatchScore, useConnection
  lib/                    supabase client, geo helpers, match score reference impl
  constants/              design tokens (theme.ts) and onboarding option lists
  types/                  profile.ts — mirrors the DB schema
supabase/
  migrations/             SQL — run these against your project
  functions/
    update_location/      Edge Function — the ONLY writer of location columns
    get_match_score/       (see README inside — implemented as SQL instead)
```

## Known placeholders / next steps

These are flagged inline in the code with comments, listed here for visibility:

- **Discovery query is a flat `.limit(50)`** (`useNearbyProfiles.ts`). For a
  real radius query, enable the PostGIS extension and switch
  `approx_latitude`/`approx_longitude` to a `geography(Point, 4326)` column
  with `ST_DWithin`. Noted as a TODO in `0001_init.sql`.
- **List-view distance labels are computed client-side** against a
  hardcoded center point in `discover.tsx`, since the viewer's own
  `approx_*` location isn't yet exposed back to their own client. Replace
  with a server-computed bucketed distance once that endpoint exists.
- **`assets/icon.png` is a solid teal placeholder** — swap it for a real app icon (1024x1024 PNG) before shipping to the App Store / Play Store.
- **No push notifications** for new connection requests or messages.
- **No realtime chat** — Messages tab lists accepted connections but
  doesn't yet open a live thread. Supabase Realtime would be the natural
  fit; wire up a `messages` table + subscription when ready.
- **30-day re-request cooldown** after a decline (mentioned in the PRD) is
  not yet enforced — the `connections` table allows a new row once the
  old one is deleted, but there's no cooldown check yet.
- **Turning off "Discoverable" hides a peer's name in Messages.** Since
  Messages looks up names via `public_profiles` (which filters to
  `discoverable = true`), a connected peer who later goes undiscoverable
  will show as "VibeCheck User" instead of their name. The connection
  itself still works — only the display name degrades. Fixing this
  properly means letting connected peers read each other's name even when
  not discoverable, which needs its own RLS policy rather than reusing
  the discovery view.
