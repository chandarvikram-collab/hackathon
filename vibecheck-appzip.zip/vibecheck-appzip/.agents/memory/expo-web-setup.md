---
name: Expo Web Setup for VibeCheck
description: Lessons learned making Expo 51 + Supabase + react-native-maps run on web in Replit, including demo mode architecture.
---

# Expo Web Setup Decisions

## Rule
Use `"output": "single"` (SPA mode) in `app.json` → `expo.web`; never `"static"` with Supabase.

**Why:** `"static"` mode enables SSR in Node.js. Supabase's Realtime client throws "Node.js 20 detected without native WebSocket support" during server-side rendering, and AsyncStorage throws "window is not defined". SPA mode runs entirely client-side and avoids both.

**How to apply:** `app.json` → `"web": { "bundler": "metro", "output": "single" }`.

## Rule
`react-native-maps` must be isolated in `.native.tsx` files; never imported (even conditionally) in shared files.

**Why:** Metro bundles all `require()` calls statically — even inside `if (Platform.OS !== 'web')` blocks. Any file that imports react-native-maps will cause web bundling to fail.

**How to apply:** Create `src/components/NearbyMap.native.tsx` (real maps) and `src/components/NearbyMap.web.tsx` (fallback). Also create `src/components/NearbyMap.tsx` as a TypeScript stub that re-exports from `.web` — TypeScript resolves it, Metro ignores it (it always prefers the platform-specific extension).

## Rule
Use inline `style={{...}}` props, not NativeWind `className`, in all web-critical screens.

**Why:** NativeWind v2 web support is incomplete. className props may not render their CSS on web, making the layout completely unstyled. Inline styles are always reliable on both platforms.

**How to apply:** Use `style={{...}}` everywhere. For NativeWind TypeScript types, add `/// <reference types="nativewind/types" />` to `nativewind-env.d.ts`.

## Demo Mode Architecture
The app ships with a full demo mode that bypasses Supabase entirely:
- `src/contexts/DemoContext.tsx` — isDemoMode flag + in-memory connection state
- `src/demo/profiles.ts` — 8 realistic mock profiles + demo user (Alex Rivera) + pre-computed scores
- `src/hooks/useAuth.tsx` — wraps DemoProvider; returns synthetic DEMO_SESSION when isDemoMode
- Each hook (`useNearbyProfiles`, `useMatchScore`, `useConnection`) checks isDemoMode and returns mock data
- `app/(auth)/sign-in.tsx` — "Try Demo" button calls `signInWithDemo()`
- `app/_layout.tsx` — skips Supabase profile check in demo mode

**Why:** Allows the app to be previewed completely without Supabase credentials, making it a truly "working" demo out of the box.

## Packages required for web
- `react-native-web@~0.19.10` + `react-dom@18.2.0` — Expo web peer deps
- `@opentelemetry/api` — Supabase JS peer dep missing from web bundle
- `ws@^8` — WebSocket polyfill (guards against Node.js realtime errors)

## Supabase client init
Pass a placeholder valid HTTPS URL when env vars are absent so the Supabase constructor doesn't throw during module load.

## metro.config.js
Must exist (even minimal) so Expo uses `expo/metro-config` defaults, which handle react-native → react-native-web aliasing.
