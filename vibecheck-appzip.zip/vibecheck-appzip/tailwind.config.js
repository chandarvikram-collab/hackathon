/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // PRD 3.1 / 3.2 color scheme
        navy: "#1E293B",
        canvas: "#F8FAFC",
        teal: "#0D9488",
        amber: "#D97706",
        purple: "#7C3AED",
        slate: "#475569",
        slateLight: "#94A3B8",
        border: "#CBD5E1",
        danger: "#B91C1C",
      },
    },
  },
  plugins: [],
};
