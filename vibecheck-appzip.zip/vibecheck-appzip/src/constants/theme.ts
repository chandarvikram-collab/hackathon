// Design tokens, lifted directly from the VibeCheck PRD (Section 3).
// Keep this as the single source of truth for color — don't hardcode
// hexes elsewhere.

export const COLORS = {
  navy: "#1E293B",
  canvas: "#F8FAFC",
  teal: "#0D9488",
  tealBlur: "rgba(13, 148, 136, 0.2)", // PRD 3.1 — proximity blur, 20% opacity
  amber: "#D97706",
  purple: "#7C3AED",
  slate: "#475569",
  slateLight: "#94A3B8",
  border: "#CBD5E1",
  danger: "#B91C1C",
  white: "#FFFFFF",
  black: "#000000",
} as const;

/**
 * PRD 3.2 — VibeMatch Bar color bands.
 * 0-49%: Amber (complementary differences, not "a bad score")
 * 50-79%: Teal (solid baseline)
 * 80-100%: Purple (high alignment)
 */
export function matchColorForScore(score: number): string {
  if (score >= 80) return COLORS.purple;
  if (score >= 50) return COLORS.teal;
  return COLORS.amber;
}

export function matchLabelForScore(score: number): string {
  if (score >= 80) return "High alignment";
  if (score >= 50) return "Solid baseline";
  return "Complementary differences";
}

// PRD 3.1 — proximity pulse radius range, used for the SVG circle on the map
export const PROXIMITY_RADIUS_MIN_M = 300;
export const PROXIMITY_RADIUS_MAX_M = 500;

// PRD 4.3 — randomized offset range applied server-side to obscure exact location
export const LOCATION_OFFSET_MIN_M = 100;
export const LOCATION_OFFSET_MAX_M = 500;
