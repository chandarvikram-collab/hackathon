// Structured option sets for onboarding Steps 1 & 3 (PRD Section 5.1 / 5.3).
// These are intentionally fixed enums (not free text) so the matching
// algorithm can compare them directly.

export const CORE_SKILL_SUGGESTIONS = [
  "Python",
  "JavaScript/TypeScript",
  "Product Management",
  "UX/UI Design",
  "B2B Sales",
  "Public Speaking",
  "Copywriting",
  "Data Analysis",
  "Fundraising",
  "Growth Marketing",
  "People Management",
  "Negotiation",
  "Graphic Design",
  "Video Production",
  "Operations",
  "Customer Success",
] as const;

export const IDEAL_CONNECTION_OPTIONS = [
  { value: "peers", label: "Peers to swap notes with" },
  { value: "mentors", label: "Mentors for guidance" },
  { value: "mentees", label: "Mentees to invest in" },
  { value: "cofounders", label: "Co-founders and collaborators" },
] as const;

export const BRAINSTORMING_STYLE_OPTIONS = [
  { value: "group", label: "Bouncing ideas around in a lively group" },
  { value: "one_on_one", label: "Deep 1-on-1 strategy sessions" },
  { value: "async", label: "Quietly sharing feedback over text or docs" },
] as const;

export const PREFERRED_MEDIUM_OPTIONS = [
  { value: "virtual_coffee", label: "Quick virtual coffee chats" },
  { value: "local_meetup", label: "Casual local meetups" },
  { value: "text", label: "Casual text messaging" },
  { value: "structured_project", label: "Deep-dive structured projects" },
] as const;

// Complementary pairings used by the match algorithm (PRD 4.2, W_collab).
// A perfect match on the *same* value also counts as a full match.
export const COMPLEMENTARY_IDEAL_CONNECTION: Record<string, string> = {
  mentors: "mentees",
  mentees: "mentors",
  peers: "peers",
  cofounders: "cofounders",
};

export type IdealConnectionValue = (typeof IDEAL_CONNECTION_OPTIONS)[number]["value"];
export type BrainstormingStyleValue = (typeof BRAINSTORMING_STYLE_OPTIONS)[number]["value"];
export type PreferredMediumValue = (typeof PREFERRED_MEDIUM_OPTIONS)[number]["value"];
