/**
 * Demo mode context — shared between hooks so they can all switch to
 * local mock data without touching any real Supabase calls.
 */
import { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { Connection } from "@/types/profile";
import { DEMO_VIEWER_ID } from "@/demo/profiles";

interface DemoContextValue {
  isDemoMode: boolean;
  enableDemoMode: () => void;
  disableDemoMode: () => void;
  // In-memory connection state for demo (so "Connect" buttons actually work)
  demoConnections: Connection[];
  upsertDemoConnection: (conn: Connection) => void;
  updateDemoConnectionStatus: (id: string, status: "accepted" | "declined") => void;
}

const DemoContext = createContext<DemoContextValue | undefined>(undefined);

export function DemoProvider({ children }: { children: ReactNode }) {
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [demoConnections, setDemoConnections] = useState<Connection[]>([]);

  const enableDemoMode = useCallback(() => setIsDemoMode(true), []);
  const disableDemoMode = useCallback(() => {
    setIsDemoMode(false);
    setDemoConnections([]);
  }, []);

  const upsertDemoConnection = useCallback((conn: Connection) => {
    setDemoConnections((prev) => {
      const exists = prev.find((c) => c.id === conn.id);
      return exists ? prev.map((c) => (c.id === conn.id ? conn : c)) : [...prev, conn];
    });
  }, []);

  const updateDemoConnectionStatus = useCallback(
    (id: string, status: "accepted" | "declined") => {
      setDemoConnections((prev) =>
        prev.map((c) => (c.id === id ? { ...c, status } : c))
      );
    },
    []
  );

  return (
    <DemoContext.Provider
      value={{
        isDemoMode,
        enableDemoMode,
        disableDemoMode,
        demoConnections,
        upsertDemoConnection,
        updateDemoConnectionStatus,
      }}
    >
      {children}
    </DemoContext.Provider>
  );
}

export function useDemo() {
  const ctx = useContext(DemoContext);
  if (!ctx) throw new Error("useDemo must be used inside DemoProvider");
  return ctx;
}

/** Convenience: generate a stable connection id for a pair of user IDs */
export function demoPairId(a: string, b: string): string {
  return [a, b].sort().join("--");
}
