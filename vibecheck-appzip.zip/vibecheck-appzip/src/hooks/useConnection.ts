import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Connection, ConnectionStatus } from "@/types/profile";
import { useDemo, demoPairId } from "@/contexts/DemoContext";
import { DEMO_VIEWER_ID } from "@/demo/profiles";

type RelationshipState =
  | "none"
  | "pending_sent"
  | "pending_received"
  | "connected"
  | "declined_cooldown";

export function useConnection(viewerId: string | undefined, targetId: string | undefined) {
  const { isDemoMode, demoConnections, upsertDemoConnection, updateDemoConnectionStatus } =
    useDemo();
  const [connection, setConnection] = useState<Connection | null>(null);
  const [loading, setLoading] = useState(true);

  // ── Demo mode ────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!isDemoMode) return;
    if (!viewerId || !targetId) {
      setConnection(null);
      setLoading(false);
      return;
    }
    const id = demoPairId(viewerId, targetId);
    const found = demoConnections.find((c) => c.id === id) ?? null;
    setConnection(found);
    setLoading(false);
  }, [isDemoMode, viewerId, targetId, demoConnections]);

  // ── Live mode ─────────────────────────────────────────────────────────────
  const refresh = useCallback(async () => {
    if (isDemoMode) return; // handled by the effect above
    if (!viewerId || !targetId) {
      setConnection(null);
      setLoading(false);
      return;
    }
    setLoading(true);

    const { data, error } = await supabase
      .from("connections")
      .select("*")
      .or(
        `and(requester_id.eq.${viewerId},recipient_id.eq.${targetId}),and(requester_id.eq.${targetId},recipient_id.eq.${viewerId})`
      )
      .maybeSingle();

    if (error) {
      console.warn("[useConnection] fetch error:", error.message);
      setConnection(null);
    } else {
      setConnection((data as Connection) ?? null);
    }
    setLoading(false);
  }, [viewerId, targetId, isDemoMode]);

  useEffect(() => {
    if (!isDemoMode) refresh();
  }, [refresh, isDemoMode]);

  // ── Derived state ─────────────────────────────────────────────────────────
  function relationshipState(): RelationshipState {
    if (!connection) return "none";
    if (connection.status === "accepted") return "connected";
    if (connection.status === "pending") {
      return connection.requester_id === viewerId ? "pending_sent" : "pending_received";
    }
    if (connection.status === "declined") return "declined_cooldown";
    return "none";
  }

  // ── Actions ───────────────────────────────────────────────────────────────
  async function sendRequest() {
    if (!viewerId || !targetId) return { error: "Missing user ids" };

    if (isDemoMode) {
      const newConn: Connection = {
        id: demoPairId(viewerId, targetId),
        requester_id: viewerId,
        recipient_id: targetId,
        status: "pending",
        created_at: new Date().toISOString(),
      };
      upsertDemoConnection(newConn);
      return { error: null };
    }

    const { error } = await supabase
      .from("connections")
      .insert({ requester_id: viewerId, recipient_id: targetId, status: "pending" });
    if (!error) await refresh();
    return { error: error?.message ?? null };
  }

  async function respondToRequest(status: ConnectionStatus) {
    if (!connection) return { error: "No connection to respond to" };

    if (isDemoMode) {
      updateDemoConnectionStatus(connection.id, status as "accepted" | "declined");
      return { error: null };
    }

    const { error } = await supabase
      .from("connections")
      .update({ status })
      .eq("id", connection.id);
    if (!error) await refresh();
    return { error: error?.message ?? null };
  }

  return {
    connection,
    loading,
    relationshipState: relationshipState(),
    sendRequest,
    respondToRequest,
    refresh,
  };
}
