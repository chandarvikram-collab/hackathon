import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useDemo } from "@/contexts/DemoContext";
import { DEMO_SCORES } from "@/demo/profiles";

interface UseMatchScoreResult {
  score: number | null;
  loading: boolean;
  error: string | null;
}

/**
 * Calls the get_match_score Postgres RPC (PRD 4.2).
 * In demo mode, returns pre-computed scores from the mock data set.
 */
export function useMatchScore(
  viewerId: string | undefined,
  targetId: string | undefined
): UseMatchScoreResult {
  const { isDemoMode } = useDemo();
  const [score, setScore] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!viewerId || !targetId) {
      setLoading(false);
      return;
    }

    if (isDemoMode) {
      setScore(null);
      setLoading(true);
      // Animate in with a short delay so the bar feels live
      const t = setTimeout(() => {
        setScore(DEMO_SCORES[targetId] ?? 50);
        setLoading(false);
      }, 700);
      return () => clearTimeout(t);
    }

    let cancelled = false;
    setLoading(true);
    setError(null);

    supabase
      .rpc("get_match_score", { viewer_id: viewerId, target_id: targetId })
      .then(({ data, error: rpcError }) => {
        if (cancelled) return;
        if (rpcError) {
          setError(rpcError.message);
        } else {
          setScore(typeof data === "number" ? data : null);
        }
        setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [viewerId, targetId, isDemoMode]);

  return { score, loading, error };
}
