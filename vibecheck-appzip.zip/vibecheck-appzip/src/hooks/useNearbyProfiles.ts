import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { PublicProfile } from "@/types/profile";
import { useDemo } from "@/contexts/DemoContext";
import { MOCK_PROFILES } from "@/demo/profiles";

interface UseNearbyProfilesResult {
  profiles: PublicProfile[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

/**
 * Fetches discoverable profiles from the `public_profiles` VIEW (PRD 4.1).
 * In demo mode, returns mock profiles immediately without hitting Supabase.
 */
export function useNearbyProfiles(currentUserId: string | undefined): UseNearbyProfilesResult {
  const { isDemoMode } = useDemo();
  const [profiles, setProfiles] = useState<PublicProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);

    if (isDemoMode) {
      // Simulate a brief network delay so the loading state is visible
      await new Promise((r) => setTimeout(r, 600));
      setProfiles(MOCK_PROFILES);
      setLoading(false);
      return;
    }

    const { data, error: fetchError } = await supabase
      .from("public_profiles")
      .select("*")
      .neq("id", currentUserId ?? "")
      .limit(50);

    if (fetchError) {
      setError(fetchError.message);
      setProfiles([]);
    } else {
      setProfiles((data ?? []) as PublicProfile[]);
    }
    setLoading(false);
  }, [currentUserId, isDemoMode]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { profiles, loading, error, refresh };
}
