import { Session } from "@supabase/supabase-js";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { supabase } from "@/lib/supabase";
import { useDemo } from "@/contexts/DemoContext";
import { DEMO_VIEWER_ID } from "@/demo/profiles";

// Minimal session-shaped object for demo mode. The app only reads
// session?.user.id and uses session as a truthy gate — nothing else.
const DEMO_SESSION = {
  user: { id: DEMO_VIEWER_ID, email: "demo@vibecheck.app", aud: "authenticated" },
  access_token: "demo-token",
  token_type: "bearer",
} as unknown as Session;

interface AuthContextValue {
  session: Session | null;
  initializing: boolean;
  signInWithEmail: (email: string, password: string) => Promise<{ error: string | null }>;
  signUpWithEmail: (email: string, password: string) => Promise<{ error: string | null }>;
  signInWithDemo: () => void;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { isDemoMode, enableDemoMode, disableDemoMode } = useDemo();
  const [session, setSession] = useState<Session | null>(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    // In demo mode the session is synthetic — skip Supabase entirely.
    if (isDemoMode) {
      setInitializing(false);
      return;
    }

    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setInitializing(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });

    return () => {
      listener.subscription.unsubscribe();
    };
  }, [isDemoMode]);

  function signInWithDemo() {
    enableDemoMode();
    // session is derived below from isDemoMode — no setState needed
  }

  async function signInWithEmail(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  }

  async function signUpWithEmail(email: string, password: string) {
    const { error } = await supabase.auth.signUp({ email, password });
    return { error: error?.message ?? null };
  }

  async function signOut() {
    if (isDemoMode) {
      disableDemoMode();
      setSession(null);
      return;
    }
    await supabase.auth.signOut();
  }

  const effectiveSession = isDemoMode ? DEMO_SESSION : session;

  return (
    <AuthContext.Provider
      value={{
        session: effectiveSession,
        initializing,
        signInWithEmail,
        signUpWithEmail,
        signInWithDemo,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
