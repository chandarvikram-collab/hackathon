import { createContext, useContext, useState, ReactNode } from "react";
import { EMPTY_PROFILE_DRAFT, ProfileDraft } from "@/types/profile";

interface OnboardingContextValue {
  draft: ProfileDraft;
  update: (patch: Partial<ProfileDraft>) => void;
  reset: () => void;
}

const OnboardingContext = createContext<OnboardingContextValue | undefined>(undefined);

export function OnboardingProvider({ children }: { children: ReactNode }) {
  const [draft, setDraft] = useState<ProfileDraft>(EMPTY_PROFILE_DRAFT);

  function update(patch: Partial<ProfileDraft>) {
    setDraft((prev) => ({ ...prev, ...patch }));
  }

  function reset() {
    setDraft(EMPTY_PROFILE_DRAFT);
  }

  return <OnboardingContext.Provider value={{ draft, update, reset }}>{children}</OnboardingContext.Provider>;
}

export function useOnboarding() {
  const ctx = useContext(OnboardingContext);
  if (!ctx) throw new Error("useOnboarding must be used within an OnboardingProvider");
  return ctx;
}
