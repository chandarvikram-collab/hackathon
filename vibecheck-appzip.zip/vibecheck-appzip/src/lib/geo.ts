import { ProximityBand } from "@/types/profile";

/**
 * Haversine distance in meters between two lat/lng points.
 *
 * NOTE per PRD 4.3: in production this calculation happens server-side
 * against exact_latitude/exact_longitude, and only the bucketed band
 * (see bucketDistance below) is ever sent to the client. This helper
 * exists for local dev/testing against the approx_* coordinates only —
 * never wire this up to call exact coordinates from the client.
 */
export function haversineMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export function bucketDistance(meters: number): ProximityBand {
  if (meters < 500) return "very_close";
  if (meters < 1609) return "nearby"; // ~1 mile
  if (meters < 3000) return "same_neighborhood";
  return "same_area";
}

/**
 * Generates a random offset point for obfuscating a coordinate, per PRD 4.3.
 * This is the logic that belongs in the Supabase Edge Function
 * (supabase/functions/update_location), shown here in TypeScript so the
 * same logic is easy to port. Do NOT call this client-side in production —
 * the client should send the exact coordinate over HTTPS to the edge
 * function and let the backend compute + store the offset.
 */
export function randomOffsetCoordinate(
  lat: number,
  lon: number,
  minMeters: number,
  maxMeters: number
): { lat: number; lon: number } {
  const distance = minMeters + Math.random() * (maxMeters - minMeters);
  const bearing = Math.random() * 2 * Math.PI;

  const R = 6371000;
  const latRad = (lat * Math.PI) / 180;
  const lonRad = (lon * Math.PI) / 180;

  const newLatRad = Math.asin(
    Math.sin(latRad) * Math.cos(distance / R) +
      Math.cos(latRad) * Math.sin(distance / R) * Math.cos(bearing)
  );
  const newLonRad =
    lonRad +
    Math.atan2(
      Math.sin(bearing) * Math.sin(distance / R) * Math.cos(latRad),
      Math.cos(distance / R) - Math.sin(latRad) * Math.sin(newLatRad)
    );

  return {
    lat: (newLatRad * 180) / Math.PI,
    lon: (newLonRad * 180) / Math.PI,
  };
}
