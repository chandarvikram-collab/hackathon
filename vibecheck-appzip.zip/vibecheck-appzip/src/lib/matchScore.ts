import {
  COMPLEMENTARY_IDEAL_CONNECTION,
} from "@/constants/profileOptions";
import { PublicProfile } from "@/types/profile";

/**
 * Reference implementation of the VibeMatch formula (PRD 4.2):
 *   Score = 0.40 * skills + 0.35 * collab + 0.25 * medium
 *
 * IMPORTANT: This function is intentionally NOT called anywhere in the
 * screens. Per PRD 4.2's "Move Match Scoring Server-Side" flag, the app
 * calls supabase.rpc("get_match_score", ...) instead (see
 * src/hooks/useMatchScore.ts), which runs the equivalent SQL version of
 * this logic inside Postgres (see supabase/functions/get_match_score).
 *
 * This file is kept as (a) documentation of the exact algorithm, and
 * (b) for local unit testing without hitting the network.
 */
export function calculateMatchScore(
  viewer: Pick<PublicProfile, "core_skills" | "skills_horizon" | "ideal_connection" | "preferred_medium">,
  target: Pick<PublicProfile, "core_skills" | "skills_horizon" | "ideal_connection" | "preferred_medium">
): number {
  const skillsScore = skillsOverlapScore(viewer, target);
  const collabScore = collaborationScore(viewer.ideal_connection, target.ideal_connection);
  const mediumScore = mediumScore_(viewer.preferred_medium, target.preferred_medium);

  const total = 0.4 * skillsScore + 0.35 * collabScore + 0.25 * mediumScore;
  return Math.round(total * 100);
}

function normalizeSkillList(skills: string[]): Set<string> {
  return new Set(skills.map((s) => s.trim().toLowerCase()));
}

function skillsOverlapScore(
  viewer: Pick<PublicProfile, "core_skills" | "skills_horizon">,
  target: Pick<PublicProfile, "core_skills" | "skills_horizon">
): number {
  // Viewer's core_skills vs target's skills_horizon, and vice versa —
  // rewards "I have what you want to learn" pairings in both directions.
  const viewerSkills = normalizeSkillList(viewer.core_skills);
  const targetSkills = normalizeSkillList(target.core_skills);

  const viewerWantsFromTarget = (viewer.skills_horizon ?? "")
    .toLowerCase()
    .split(/[,\s]+/)
    .filter(Boolean);
  const targetWantsFromViewer = (target.skills_horizon ?? "")
    .toLowerCase()
    .split(/[,\s]+/)
    .filter(Boolean);

  const aToB = targetWantsFromViewer.some((want) =>
    [...viewerSkills].some((s) => s.includes(want) || want.includes(s))
  );
  const bToA = viewerWantsFromTarget.some((want) =>
    [...targetSkills].some((s) => s.includes(want) || want.includes(s))
  );

  // Direct overlap between the two core_skills lists too.
  const directOverlap = [...viewerSkills].some((s) => targetSkills.has(s));

  let score = 0;
  if (aToB) score += 0.45;
  if (bToA) score += 0.45;
  if (directOverlap) score += 0.1;

  return Math.min(score, 1);
}

function collaborationScore(viewerStyle: string, targetStyle: string): number {
  if (!viewerStyle || !targetStyle) return 0;
  if (viewerStyle === targetStyle) return 1;
  if (COMPLEMENTARY_IDEAL_CONNECTION[viewerStyle] === targetStyle) return 1;
  return 0.2; // some baseline credit even on a style mismatch
}

function mediumScore_(viewerMedium: string, targetMedium: string): number {
  if (!viewerMedium || !targetMedium) return 0;
  return viewerMedium === targetMedium ? 1 : 0.15;
}
