// Mirrors the schema in supabase/migrations/0001_init.sql and PRD Section 4.1.
// IMPORTANT: exact_latitude / exact_longitude intentionally do NOT appear
// here, because the client should never receive them. If you find yourself
// adding them to this type, stop — that's almost certainly a privacy bug.

export type ConnectionStatus = "pending" | "accepted" | "declined";

export interface PublicProfile {
  id: string;
  full_name: string;
  current_role: string;
  industry: string;
  pitch: string | null;

  core_skills: string[];
  collaboration_style: string; // free-form summary, shown as a chip
  brainstorming_style: string;
  preferred_medium: string;
  ideal_connection: string;

  next_milestone: string | null;
  skills_horizon: string | null;
  industries_of_interest: string | null;
  watercooler_topic: string | null;
  current_obsession: string | null;
  win_proud_of: string | null;

  approx_latitude: number;
  approx_longitude: number;
  approx_radius_m: number;

  last_seen: string;
  discoverable: boolean;

  avatar_url?: string | null;
}

export interface OwnProfile extends PublicProfile {
  updated_at: string;
}

export interface Connection {
  id: string;
  requester_id: string;
  recipient_id: string;
  status: ConnectionStatus;
  created_at: string;
}

export interface ProfileWithDistance extends PublicProfile {
  distanceBand: ProximityBand;
}

export type ProximityBand =
  | "very_close" // < 500m
  | "nearby" // 500m - 1km
  | "same_neighborhood" // 1km - 3km
  | "same_area"; // > 3km, still within discovery bounding box

export function bandLabel(band: ProximityBand): string {
  switch (band) {
    case "very_close":
      return "Within 500m";
    case "nearby":
      return "Less than 1 mile away";
    case "same_neighborhood":
      return "In the same neighborhood";
    case "same_area":
      return "Nearby";
  }
}

// Onboarding wizard draft state, before it's written to the DB.
export interface ProfileDraft {
  full_name: string;
  current_role: string;
  industry: string;
  pitch: string;
  core_skills: string[];

  next_milestone: string;
  skills_horizon: string;
  industries_of_interest: string;

  ideal_connection: string;
  brainstorming_style: string;
  preferred_medium: string;

  watercooler_topic: string;
  current_obsession: string;
  win_proud_of: string;
}

export const EMPTY_PROFILE_DRAFT: ProfileDraft = {
  full_name: "",
  current_role: "",
  industry: "",
  pitch: "",
  core_skills: [],
  next_milestone: "",
  skills_horizon: "",
  industries_of_interest: "",
  ideal_connection: "",
  brainstorming_style: "",
  preferred_medium: "",
  watercooler_topic: "",
  current_obsession: "",
  win_proud_of: "",
};
