import { forwardRef, useMemo } from "react";
import { View, Text, ScrollView, Pressable, ActivityIndicator } from "react-native";
import BottomSheet, { BottomSheetBackdrop } from "@gorhom/bottom-sheet";
import { useRouter } from "expo-router";
import { PublicProfile } from "@/types/profile";
import { VibeMatchBar } from "@/components/VibeMatchBar";
import { useMatchScore } from "@/hooks/useMatchScore";
import { useConnection } from "@/hooks/useConnection";
import { COLORS, matchLabelForScore } from "@/constants/theme";
import {
  IDEAL_CONNECTION_OPTIONS,
  BRAINSTORMING_STYLE_OPTIONS,
  PREFERRED_MEDIUM_OPTIONS,
} from "@/constants/profileOptions";

interface ProfileDrawerProps {
  profile: PublicProfile | null;
  viewerId: string | undefined;
}

function labelFor(
  options: readonly { value: string; label: string }[],
  value: string
): string {
  return options.find((o) => o.value === value)?.label ?? value;
}

function Chip({ label, color = COLORS.teal }: { label: string; color?: string }) {
  return (
    <View
      style={{
        backgroundColor: color === COLORS.teal ? COLORS.tealBlur : "#F3F4F6",
        borderRadius: 99,
        paddingHorizontal: 12,
        paddingVertical: 6,
        marginRight: 6,
        marginBottom: 6,
      }}
    >
      <Text style={{ fontSize: 12, fontWeight: "600", color }}>{label}</Text>
    </View>
  );
}

function BlockQuote({
  label,
  text,
  accentColor,
}: {
  label: string;
  text: string;
  accentColor: string;
}) {
  return (
    <View style={{ marginBottom: 16 }}>
      <Text
        style={{
          fontSize: 10,
          fontWeight: "700",
          textTransform: "uppercase",
          letterSpacing: 1,
          color: COLORS.slateLight,
          marginBottom: 6,
        }}
      >
        {label}
      </Text>
      <View
        style={{
          paddingLeft: 12,
          borderLeftWidth: 2.5,
          borderLeftColor: accentColor,
        }}
      >
        <Text style={{ fontSize: 14, color: COLORS.navy, lineHeight: 22, fontStyle: "italic" }}>
          {text}
        </Text>
      </View>
    </View>
  );
}

export const ProfileDrawer = forwardRef<BottomSheet, ProfileDrawerProps>(
  ({ profile, viewerId }, ref) => {
    const router = useRouter();
    const snapPoints = useMemo(() => ["75%"], []);
    const { score, loading: scoreLoading } = useMatchScore(viewerId, profile?.id);
    const {
      relationshipState,
      sendRequest,
      respondToRequest,
      loading: connectionLoading,
    } = useConnection(viewerId, profile?.id);

    const emptySheet = (
      <BottomSheet
        ref={ref}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backdropComponent={(props) => (
          <BottomSheetBackdrop {...props} disappearsOnIndex={-1} appearsOnIndex={0} />
        )}
      >
        <View />
      </BottomSheet>
    );

    if (!profile) return emptySheet;

    async function handleFooterAction() {
      if (!profile) return;
      if (relationshipState === "none") {
        await sendRequest();
      } else if (relationshipState === "pending_received") {
        await respondToRequest("accepted");
      } else if (relationshipState === "connected") {
        router.push(`/(tabs)/messages?with=${profile.id}`);
      }
    }

    const footerLabels: Record<typeof relationshipState, string> = {
      none: "Connect",
      pending_sent: "Request Sent",
      pending_received: "Accept Request",
      connected: "Message",
      declined_cooldown: "Not Available",
    };

    const footerDisabled =
      relationshipState === "pending_sent" ||
      relationshipState === "declined_cooldown" ||
      connectionLoading;

    const footerBg =
      relationshipState === "connected"
        ? COLORS.purple
        : COLORS.teal;

    const initials = profile.full_name
      .split(" ")
      .map((w) => w[0])
      .join("")
      .slice(0, 2)
      .toUpperCase();

    return (
      <BottomSheet
        ref={ref}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backdropComponent={(props) => (
          <BottomSheetBackdrop {...props} disappearsOnIndex={-1} appearsOnIndex={0} />
        )}
        handleIndicatorStyle={{ backgroundColor: COLORS.border, width: 40 }}
        backgroundStyle={{ borderTopLeftRadius: 24, borderTopRightRadius: 24 }}
      >
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
        >
          {/* Avatar + name */}
          <View style={{ alignItems: "center", marginTop: 4, marginBottom: 20 }}>
            <View
              style={{
                width: 72,
                height: 72,
                borderRadius: 36,
                backgroundColor: COLORS.teal,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <Text style={{ fontSize: 26, fontWeight: "800", color: "white" }}>{initials}</Text>
            </View>
            <Text style={{ fontSize: 20, fontWeight: "800", color: COLORS.navy }}>
              {profile.full_name}
            </Text>
            <Text style={{ fontSize: 13, color: COLORS.slate, marginTop: 4 }}>
              {profile.current_role} · {profile.industry}
            </Text>
          </View>

          {/* VibeMatch bar */}
          <View style={{ marginBottom: 6 }}>
            <VibeMatchBar score={scoreLoading ? null : score} />
          </View>
          {score !== null && !scoreLoading && (
            <Text
              style={{
                fontSize: 12,
                textAlign: "center",
                color: COLORS.slateLight,
                marginBottom: 20,
              }}
            >
              {matchLabelForScore(score)}
            </Text>
          )}

          {/* Pitch */}
          {profile.pitch && (
            <View
              style={{
                backgroundColor: "#F8FAFC",
                borderRadius: 14,
                padding: 16,
                marginBottom: 20,
                borderWidth: 1,
                borderColor: COLORS.border,
              }}
            >
              <Text
                style={{ fontSize: 14, color: COLORS.navy, fontStyle: "italic", lineHeight: 22 }}
              >
                "{profile.pitch}"
              </Text>
            </View>
          )}

          {/* Skills */}
          <Text
            style={{
              fontSize: 10,
              fontWeight: "700",
              textTransform: "uppercase",
              letterSpacing: 1,
              color: COLORS.slateLight,
              marginBottom: 10,
            }}
          >
            Skills
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginBottom: 20 }}>
            {profile.core_skills.map((skill) => (
              <Chip key={skill} label={skill} color={COLORS.teal} />
            ))}
          </View>

          {/* Looking for */}
          <Text
            style={{
              fontSize: 10,
              fontWeight: "700",
              textTransform: "uppercase",
              letterSpacing: 1,
              color: COLORS.slateLight,
              marginBottom: 10,
            }}
          >
            Looking For
          </Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", marginBottom: 24 }}>
            <Chip
              label={labelFor(IDEAL_CONNECTION_OPTIONS, profile.ideal_connection)}
              color={COLORS.navy}
            />
            <Chip
              label={labelFor(BRAINSTORMING_STYLE_OPTIONS, profile.brainstorming_style)}
              color={COLORS.navy}
            />
            <Chip
              label={labelFor(PREFERRED_MEDIUM_OPTIONS, profile.preferred_medium)}
              color={COLORS.navy}
            />
          </View>

          {/* Icebreakers */}
          {profile.next_milestone && (
            <BlockQuote
              label="Next Milestone"
              text={profile.next_milestone}
              accentColor={COLORS.teal}
            />
          )}
          {profile.watercooler_topic && (
            <BlockQuote
              label="Watercooler Topic"
              text={profile.watercooler_topic}
              accentColor={COLORS.purple}
            />
          )}
          {profile.win_proud_of && (
            <BlockQuote
              label="A Win They're Proud Of"
              text={profile.win_proud_of}
              accentColor={COLORS.amber}
            />
          )}
          {profile.current_obsession && (
            <BlockQuote
              label="Current Obsession"
              text={profile.current_obsession}
              accentColor="#6B7280"
            />
          )}
        </ScrollView>

        {/* CTA footer */}
        <View
          style={{
            paddingHorizontal: 24,
            paddingBottom: 32,
            paddingTop: 12,
            borderTopWidth: 1,
            borderTopColor: COLORS.border,
          }}
        >
          <Pressable
            onPress={handleFooterAction}
            disabled={footerDisabled}
            style={{
              backgroundColor: footerBg,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              opacity: footerDisabled ? 0.5 : 1,
            }}
          >
            {connectionLoading ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text style={{ color: "white", fontWeight: "700", fontSize: 16 }}>
                {footerLabels[relationshipState]}
              </Text>
            )}
          </Pressable>
        </View>
      </BottomSheet>
    );
  }
);

ProfileDrawer.displayName = "ProfileDrawer";
