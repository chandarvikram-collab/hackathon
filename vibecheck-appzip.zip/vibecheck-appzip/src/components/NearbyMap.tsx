/**
 * Shared type stub for the platform-split NearbyMap component.
 *
 * TypeScript resolves this file when it looks for "@/components/NearbyMap".
 * Metro instead picks:
 *   NearbyMap.native.tsx  — on iOS / Android
 *   NearbyMap.web.tsx     — on web
 * …and never loads this file at runtime.
 *
 * The re-export from the web module gives TypeScript the correct prop types
 * without referencing any native-only dependency.
 */
export { NearbyMap } from "./NearbyMap.web";
