import { View, Text, Pressable } from "react-native";
import { COLORS } from "@/constants/theme";

interface ChipSelectorProps {
  options: readonly string[];
  selected: string[];
  onChange: (next: string[]) => void;
  maxSelections?: number;
}

export function ChipSelector({ options, selected, onChange, maxSelections }: ChipSelectorProps) {
  function toggle(option: string) {
    if (selected.includes(option)) {
      onChange(selected.filter((s) => s !== option));
    } else {
      if (maxSelections && selected.length >= maxSelections) return;
      onChange([...selected, option]);
    }
  }

  return (
    <View className="flex-row flex-wrap gap-2">
      {options.map((option) => {
        const isSelected = selected.includes(option);
        return (
          <Pressable
            key={option}
            onPress={() => toggle(option)}
            className="rounded-full px-4 py-2.5 border"
            style={{
              backgroundColor: isSelected ? COLORS.teal : "white",
              borderColor: isSelected ? COLORS.teal : COLORS.border,
            }}
          >
            <Text
              className="text-sm font-medium"
              style={{ color: isSelected ? "white" : COLORS.slate }}
            >
              {option}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

interface SingleSelectListProps<T extends string> {
  options: readonly { value: T; label: string }[];
  selected: T | "";
  onChange: (value: T) => void;
}

export function SingleSelectList<T extends string>({ options, selected, onChange }: SingleSelectListProps<T>) {
  return (
    <View className="gap-2.5">
      {options.map((option) => {
        const isSelected = selected === option.value;
        return (
          <Pressable
            key={option.value}
            onPress={() => onChange(option.value)}
            className="rounded-xl px-4 py-4 border flex-row items-center justify-between"
            style={{
              backgroundColor: isSelected ? COLORS.tealBlur : "white",
              borderColor: isSelected ? COLORS.teal : COLORS.border,
            }}
          >
            <Text className="text-base" style={{ color: isSelected ? COLORS.teal : COLORS.navy, fontWeight: isSelected ? "600" : "400" }}>
              {option.label}
            </Text>
            <View
              className="w-5 h-5 rounded-full border items-center justify-center"
              style={{ borderColor: isSelected ? COLORS.teal : COLORS.border }}
            >
              {isSelected && <View className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS.teal }} />}
            </View>
          </Pressable>
        );
      })}
    </View>
  );
}
