/**
 * Web fallback for the native map view.
 * react-native-maps is native-only and can't be bundled for web.
 * This component renders a teal-tinted canvas with clickable blobs
 * representing each nearby profile, giving a sense of spatial proximity
 * without requiring native map SDKs.
 */
import { View, Text, Pressable } from "react-native";
import { PublicProfile } from "@/types/profile";
import { COLORS } from "@/constants/theme";

interface NearbyMapProps {
  profiles: PublicProfile[];
  onSelectProfile: (profile: PublicProfile) => void;
}

// Deterministic position from profile ID so blobs stay stable between renders
function blobPosition(id: string, index: number): { left: string; top: string } {
  const hash = id.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const col = index % 3;
  const row = Math.floor(index / 3);
  const leftBase = 12 + col * 30;
  const topBase = 15 + row * 32;
  const jitterLeft = (hash % 10) - 5;
  const jitterTop = ((hash >> 4) % 8) - 4;
  return {
    left: `${Math.min(Math.max(leftBase + jitterLeft, 5), 75)}%`,
    top: `${Math.min(Math.max(topBase + jitterTop, 8), 80)}%`,
  };
}

export function NearbyMap({ profiles, onSelectProfile }: NearbyMapProps) {
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <View
        style={{
          flex: 1,
          borderRadius: 20,
          overflow: "hidden",
          backgroundColor: "#e8f5f3",
          borderWidth: 1,
          borderColor: COLORS.border,
          position: "relative",
        }}
      >
        {profiles.slice(0, 9).map((profile, i) => {
          const pos = blobPosition(profile.id, i);
          return (
            <Pressable
              key={profile.id}
              onPress={() => onSelectProfile(profile)}
              style={{
                position: "absolute",
                left: pos.left as any,
                top: pos.top as any,
                width: 72,
                height: 72,
                borderRadius: 36,
                backgroundColor: COLORS.tealBlur,
                borderWidth: 1.5,
                borderColor: COLORS.teal,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text
                style={{
                  fontSize: 10,
                  fontWeight: "700",
                  color: COLORS.teal,
                  textAlign: "center",
                  paddingHorizontal: 4,
                }}
                numberOfLines={2}
              >
                {profile.full_name.split(" ")[0]}
              </Text>
            </Pressable>
          );
        })}

        {profiles.length === 0 && (
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
            <Text style={{ color: COLORS.slate, textAlign: "center" }}>
              No one nearby right now. Check back soon.
            </Text>
          </View>
        )}

        <View
          style={{
            position: "absolute",
            bottom: 16,
            alignSelf: "center",
            backgroundColor: "rgba(255,255,255,0.88)",
            borderRadius: 12,
            paddingHorizontal: 14,
            paddingVertical: 8,
          }}
        >
          <Text style={{ fontSize: 12, color: COLORS.slate }}>
            🗺️ Interactive map available on iOS & Android
          </Text>
        </View>
      </View>
    </View>
  );
}
