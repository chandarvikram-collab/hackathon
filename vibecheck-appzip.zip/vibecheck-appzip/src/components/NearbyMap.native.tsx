/**
 * Native-only map view using react-native-maps.
 * Metro will select this file on iOS/Android and NearbyMap.web.tsx on web.
 * Never import react-native-maps in a shared (non-.native.tsx) file.
 */
import { View } from "react-native";
import MapView, { Circle, Marker } from "react-native-maps";
import { PublicProfile } from "@/types/profile";
import { COLORS, PROXIMITY_RADIUS_MIN_M } from "@/constants/theme";

interface NearbyMapProps {
  profiles: PublicProfile[];
  onSelectProfile: (profile: PublicProfile) => void;
}

export function NearbyMap({ profiles, onSelectProfile }: NearbyMapProps) {
  return (
    <MapView
      style={{ flex: 1 }}
      initialRegion={{
        latitude: 37.3382,
        longitude: -121.8863,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      }}
    >
      {profiles.map((profile) => (
        // Circle and Marker must be direct MapView children — no View wrapper
        <View key={profile.id}>
          {/* PRD 3.1 — translucent teal pulse circle, not a pin */}
          <Circle
            center={{ latitude: profile.approx_latitude, longitude: profile.approx_longitude }}
            radius={profile.approx_radius_m || PROXIMITY_RADIUS_MIN_M}
            fillColor={COLORS.tealBlur}
            strokeColor={COLORS.teal}
            strokeWidth={1}
          />
          <Marker
            coordinate={{ latitude: profile.approx_latitude, longitude: profile.approx_longitude }}
            opacity={0} // invisible hit-target over the circle so taps work
            onPress={() => onSelectProfile(profile)}
          />
        </View>
      ))}
    </MapView>
  );
}
