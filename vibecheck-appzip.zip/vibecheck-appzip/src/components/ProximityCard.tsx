import { View, Text, Pressable } from "react-native";
import { PublicProfile } from "@/types/profile";
import { COLORS } from "@/constants/theme";

interface ProximityCardProps {
  profile: PublicProfile;
  distanceLabel: string;
  onPress: () => void;
}

export function ProximityCard({ profile, distanceLabel, onPress }: ProximityCardProps) {
  const initials = profile.full_name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "white",
        borderWidth: 1,
        borderColor: COLORS.border,
        borderRadius: 16,
        padding: 16,
        marginBottom: 10,
        opacity: pressed ? 0.85 : 1,
      })}
    >
      {/* Avatar */}
      <View
        style={{
          width: 50,
          height: 50,
          borderRadius: 25,
          backgroundColor: COLORS.teal,
          alignItems: "center",
          justifyContent: "center",
          marginRight: 14,
        }}
      >
        <Text style={{ fontSize: 16, fontWeight: "800", color: "white" }}>{initials}</Text>
      </View>

      {/* Info */}
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 15, fontWeight: "700", color: COLORS.navy }} numberOfLines={1}>
          {profile.full_name}
        </Text>
        <Text style={{ fontSize: 13, color: COLORS.slate, marginTop: 2 }} numberOfLines={1}>
          {profile.current_role} · {profile.industry}
        </Text>
      </View>

      {/* Distance badge */}
      <View
        style={{
          backgroundColor: COLORS.tealBlur,
          borderRadius: 99,
          paddingHorizontal: 10,
          paddingVertical: 5,
          marginLeft: 8,
        }}
      >
        <Text style={{ fontSize: 11, fontWeight: "700", color: COLORS.teal }}>{distanceLabel}</Text>
      </View>
    </Pressable>
  );
}
