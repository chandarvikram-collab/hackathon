import { useEffect } from "react";
import { View, Text } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  interpolateColor,
  Easing,
} from "react-native-reanimated";
import { COLORS } from "@/constants/theme";

interface VibeMatchBarProps {
  score: number | null; // null while loading
}

/**
 * PRD 3.2: animates 0% -> calculated % over 800ms, with the fill color
 * easing between Amber / Teal / Purple bands as it crosses thresholds.
 */
export function VibeMatchBar({ score }: VibeMatchBarProps) {
  const progress = useSharedValue(0);

  useEffect(() => {
    if (score !== null) {
      progress.value = withTiming(score, { duration: 800, easing: Easing.out(Easing.cubic) });
    }
  }, [score]);

  const fillStyle = useAnimatedStyle(() => {
    const color = interpolateColor(
      progress.value,
      [0, 49, 50, 79, 80, 100],
      [COLORS.amber, COLORS.amber, COLORS.teal, COLORS.teal, COLORS.purple, COLORS.purple]
    );
    return {
      width: `${progress.value}%`,
      backgroundColor: color,
    };
  });

  return (
    <View style={{ width: "100%" }}>
      <View
        style={{
          width: "100%",
          height: 36,
          borderRadius: 999,
          overflow: "hidden",
          justifyContent: "center",
          backgroundColor: COLORS.border,
        }}
      >
        <Animated.View
          style={[{ height: "100%", borderRadius: 999, position: "absolute", left: 0 }, fillStyle]}
        />
        <Text
          style={{
            textAlign: "center",
            fontSize: 14,
            fontWeight: "700",
            color: COLORS.navy,
            zIndex: 1,
          }}
        >
          {score === null ? "Calculating…" : `${score}% Vibe Match`}
        </Text>
      </View>
    </View>
  );
}
