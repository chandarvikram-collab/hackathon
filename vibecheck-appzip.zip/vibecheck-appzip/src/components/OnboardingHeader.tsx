import { View, Text } from "react-native";
import { COLORS } from "@/constants/theme";

interface OnboardingHeaderProps {
  step: 1 | 2 | 3 | 4;
  title: string;
  subtitle: string;
}

const STEP_LABELS = ["The Basics", "Growth & Ambition", "Collaboration Style", "Icebreakers"];

export function OnboardingHeader({ step, title, subtitle }: OnboardingHeaderProps) {
  return (
    <View className="px-6 pt-14 pb-6">
      <View className="flex-row gap-1.5 mb-6">
        {STEP_LABELS.map((_, i) => (
          <View
            key={i}
            className="flex-1 h-1.5 rounded-full"
            style={{ backgroundColor: i < step ? COLORS.teal : COLORS.border }}
          />
        ))}
      </View>
      <Text className="text-xs font-semibold uppercase tracking-wide mb-1.5" style={{ color: COLORS.teal }}>
        Step {step} of 4 · {STEP_LABELS[step - 1]}
      </Text>
      <Text className="text-2xl font-bold mb-1.5" style={{ color: COLORS.navy }}>
        {title}
      </Text>
      <Text className="text-base" style={{ color: COLORS.slate }}>
        {subtitle}
      </Text>
    </View>
  );
}
