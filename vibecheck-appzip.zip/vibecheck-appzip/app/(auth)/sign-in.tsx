import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { Link } from "expo-router";
import { useAuth } from "@/hooks/useAuth";
import { COLORS } from "@/constants/theme";

export default function SignInScreen() {
  const { signInWithEmail, signInWithDemo } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSignIn() {
    setError(null);
    setLoading(true);
    const { error: signInError } = await signInWithEmail(email.trim(), password);
    setLoading(false);
    if (signInError) setError(signInError);
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: COLORS.canvas }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, justifyContent: "center", paddingHorizontal: 32 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* Logo / wordmark */}
        <View style={{ marginBottom: 40 }}>
          <View
            style={{
              width: 56,
              height: 56,
              borderRadius: 16,
              backgroundColor: COLORS.teal,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 16,
            }}
          >
            <Text style={{ fontSize: 28 }}>✦</Text>
          </View>
          <Text style={{ fontSize: 32, fontWeight: "800", color: COLORS.teal, letterSpacing: -0.5 }}>
            VibeCheck
          </Text>
          <Text style={{ fontSize: 15, color: COLORS.slate, marginTop: 4 }}>
            Find people who match your wavelength, nearby.
          </Text>
        </View>

        {/* Email */}
        <Text style={{ fontSize: 13, fontWeight: "600", color: COLORS.navy, marginBottom: 6 }}>
          Email
        </Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
          placeholder="you@example.com"
          placeholderTextColor={COLORS.slateLight}
          style={{
            backgroundColor: "white",
            borderWidth: 1,
            borderColor: COLORS.border,
            borderRadius: 14,
            paddingHorizontal: 16,
            paddingVertical: 14,
            fontSize: 15,
            color: COLORS.navy,
            marginBottom: 16,
          }}
        />

        {/* Password */}
        <Text style={{ fontSize: 13, fontWeight: "600", color: COLORS.navy, marginBottom: 6 }}>
          Password
        </Text>
        <TextInput
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          placeholder="••••••••"
          placeholderTextColor={COLORS.slateLight}
          style={{
            backgroundColor: "white",
            borderWidth: 1,
            borderColor: COLORS.border,
            borderRadius: 14,
            paddingHorizontal: 16,
            paddingVertical: 14,
            fontSize: 15,
            color: COLORS.navy,
            marginBottom: 8,
          }}
        />

        {error && (
          <Text style={{ fontSize: 13, color: COLORS.danger, marginBottom: 12 }}>{error}</Text>
        )}

        {/* Sign In */}
        <Pressable
          onPress={handleSignIn}
          disabled={loading || !email || !password}
          style={{
            backgroundColor: COLORS.teal,
            borderRadius: 14,
            paddingVertical: 16,
            alignItems: "center",
            marginTop: 8,
            opacity: loading || !email || !password ? 0.55 : 1,
          }}
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={{ color: "white", fontWeight: "700", fontSize: 15 }}>Sign In</Text>
          )}
        </Pressable>

        {/* Divider */}
        <View style={{ flexDirection: "row", alignItems: "center", marginVertical: 20 }}>
          <View style={{ flex: 1, height: 1, backgroundColor: COLORS.border }} />
          <Text style={{ color: COLORS.slateLight, marginHorizontal: 12, fontSize: 13 }}>or</Text>
          <View style={{ flex: 1, height: 1, backgroundColor: COLORS.border }} />
        </View>

        {/* Try Demo — works without Supabase credentials */}
        <Pressable
          onPress={signInWithDemo}
          style={{
            backgroundColor: "white",
            borderWidth: 2,
            borderColor: COLORS.teal,
            borderRadius: 14,
            paddingVertical: 16,
            alignItems: "center",
          }}
        >
          <Text style={{ color: COLORS.teal, fontWeight: "700", fontSize: 15 }}>
            ✦ Try Demo
          </Text>
          <Text style={{ color: COLORS.slate, fontSize: 12, marginTop: 2 }}>
            Explore with sample profiles — no account needed
          </Text>
        </Pressable>

        {/* Sign up link */}
        <Link href="/(auth)/sign-up" asChild>
          <Pressable style={{ marginTop: 24, alignItems: "center" }}>
            <Text style={{ color: COLORS.slate, fontSize: 14 }}>
              New here?{" "}
              <Text style={{ color: COLORS.teal, fontWeight: "600" }}>Create an account</Text>
            </Text>
          </Pressable>
        </Link>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
