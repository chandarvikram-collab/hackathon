import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { Link } from "expo-router";
import { useAuth } from "@/hooks/useAuth";
import { COLORS } from "@/constants/theme";

export default function SignUpScreen() {
  const { signUpWithEmail } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmationSent, setConfirmationSent] = useState(false);

  async function handleSignUp() {
    setError(null);
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    setLoading(true);
    const { error: signUpError } = await signUpWithEmail(email.trim(), password);
    setLoading(false);
    if (signUpError) {
      setError(signUpError);
    } else {
      setConfirmationSent(true);
    }
  }

  if (confirmationSent) {
    return (
      <View style={{ flex: 1, justifyContent: "center", paddingHorizontal: 32, backgroundColor: COLORS.canvas }}>
        <Text style={{ fontSize: 24, fontWeight: "800", color: COLORS.navy, marginBottom: 12 }}>
          Check your email ✉️
        </Text>
        <Text style={{ fontSize: 15, color: COLORS.slate, marginBottom: 32, lineHeight: 24 }}>
          We sent a confirmation link to {email}.{"\n"}Tap it, then come back and sign in.
        </Text>
        <Link href="/(auth)/sign-in" asChild>
          <Pressable
            style={{
              backgroundColor: COLORS.teal,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
            }}
          >
            <Text style={{ color: "white", fontWeight: "700", fontSize: 15 }}>Back to Sign In</Text>
          </Pressable>
        </Link>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: COLORS.canvas }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, justifyContent: "center", paddingHorizontal: 32 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={{ marginBottom: 40 }}>
          <View
            style={{
              width: 56,
              height: 56,
              borderRadius: 16,
              backgroundColor: COLORS.teal,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 16,
            }}
          >
            <Text style={{ fontSize: 28 }}>✦</Text>
          </View>
          <Text style={{ fontSize: 30, fontWeight: "800", color: COLORS.teal, letterSpacing: -0.5 }}>
            Join VibeCheck
          </Text>
          <Text style={{ fontSize: 14, color: COLORS.slate, marginTop: 6, lineHeight: 22 }}>
            We'll only ever show others an approximate area, never your exact location.
          </Text>
        </View>

        {/* Email */}
        <Text style={{ fontSize: 13, fontWeight: "600", color: COLORS.navy, marginBottom: 6 }}>
          Email
        </Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
          placeholder="you@example.com"
          placeholderTextColor={COLORS.slateLight}
          style={{
            backgroundColor: "white",
            borderWidth: 1,
            borderColor: COLORS.border,
            borderRadius: 14,
            paddingHorizontal: 16,
            paddingVertical: 14,
            fontSize: 15,
            color: COLORS.navy,
            marginBottom: 16,
          }}
        />

        {/* Password */}
        <Text style={{ fontSize: 13, fontWeight: "600", color: COLORS.navy, marginBottom: 6 }}>
          Password
        </Text>
        <TextInput
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          placeholder="At least 8 characters"
          placeholderTextColor={COLORS.slateLight}
          style={{
            backgroundColor: "white",
            borderWidth: 1,
            borderColor: COLORS.border,
            borderRadius: 14,
            paddingHorizontal: 16,
            paddingVertical: 14,
            fontSize: 15,
            color: COLORS.navy,
            marginBottom: 8,
          }}
        />

        {error && (
          <Text style={{ fontSize: 13, color: COLORS.danger, marginBottom: 12 }}>{error}</Text>
        )}

        {/* CTA */}
        <Pressable
          onPress={handleSignUp}
          disabled={loading || !email || !password}
          style={{
            backgroundColor: COLORS.teal,
            borderRadius: 14,
            paddingVertical: 16,
            alignItems: "center",
            marginTop: 8,
            opacity: loading || !email || !password ? 0.55 : 1,
          }}
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={{ color: "white", fontWeight: "700", fontSize: 15 }}>Create Account</Text>
          )}
        </Pressable>

        {/* Sign in link */}
        <Link href="/(auth)/sign-in" asChild>
          <Pressable style={{ marginTop: 24, alignItems: "center" }}>
            <Text style={{ color: COLORS.slate, fontSize: 14 }}>
              Already have an account?{" "}
              <Text style={{ color: COLORS.teal, fontWeight: "600" }}>Sign in</Text>
            </Text>
          </Pressable>
        </Link>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
