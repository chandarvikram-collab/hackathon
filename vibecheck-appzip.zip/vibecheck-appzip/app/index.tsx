import { Redirect } from "expo-router";

// All real routing logic lives in app/_layout.tsx (RootNavigation), which
// inspects auth + profile-existence state and redirects accordingly. This
// file exists only because Expo Router expects an index route at the root.
export default function Index() {
  return <Redirect href="/(auth)/sign-in" />;
}
