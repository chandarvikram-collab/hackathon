import { View, Text, Pressable, ScrollView } from "react-native";
import { useRouter } from "expo-router";
import { OnboardingHeader } from "@/components/OnboardingHeader";
import { SingleSelectList } from "@/components/ChipSelector";
import { useOnboarding } from "@/hooks/useOnboarding";
import {
  IDEAL_CONNECTION_OPTIONS,
  BRAINSTORMING_STYLE_OPTIONS,
  PREFERRED_MEDIUM_OPTIONS,
} from "@/constants/profileOptions";
import { COLORS } from "@/constants/theme";

export default function OnboardingStep3() {
  const router = useRouter();
  const { draft, update } = useOnboarding();

  const canContinue =
    draft.ideal_connection.length > 0 &&
    draft.brainstorming_style.length > 0 &&
    draft.preferred_medium.length > 0;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: COLORS.canvas }}
      contentContainerStyle={{ flexGrow: 1 }}
    >
      <OnboardingHeader
        step={3}
        title="Collaboration Style"
        subtitle="People network differently. Let's avoid awkward, mismatched expectations."
      />

      <View style={{ paddingHorizontal: 24, gap: 28 }}>
        <View>
          <Text
            style={{ fontSize: 13, fontWeight: "600", color: COLORS.navy, marginBottom: 12 }}
          >
            Who are you looking to meet right now?
          </Text>
          <SingleSelectList
            options={IDEAL_CONNECTION_OPTIONS}
            selected={draft.ideal_connection as any}
            onChange={(v) => update({ ideal_connection: v })}
          />
        </View>

        <View>
          <Text
            style={{ fontSize: 13, fontWeight: "600", color: COLORS.navy, marginBottom: 12 }}
          >
            How do you get your best work done?
          </Text>
          <SingleSelectList
            options={BRAINSTORMING_STYLE_OPTIONS}
            selected={draft.brainstorming_style as any}
            onChange={(v) => update({ brainstorming_style: v })}
          />
        </View>

        <View>
          <Text
            style={{ fontSize: 13, fontWeight: "600", color: COLORS.navy, marginBottom: 12 }}
          >
            What's your favorite way to connect?
          </Text>
          <SingleSelectList
            options={PREFERRED_MEDIUM_OPTIONS}
            selected={draft.preferred_medium as any}
            onChange={(v) => update({ preferred_medium: v })}
          />
        </View>
      </View>

      <View
        style={{
          flexDirection: "row",
          gap: 12,
          paddingHorizontal: 24,
          paddingVertical: 28,
          marginTop: 8,
        }}
      >
        <Pressable
          onPress={() => router.back()}
          style={{
            flex: 1,
            borderWidth: 1,
            borderColor: COLORS.border,
            borderRadius: 14,
            paddingVertical: 16,
            alignItems: "center",
          }}
        >
          <Text style={{ fontWeight: "700", fontSize: 15, color: COLORS.slate }}>Back</Text>
        </Pressable>
        <Pressable
          onPress={() => router.push("/onboarding/step-4")}
          disabled={!canContinue}
          style={{
            flex: 1,
            backgroundColor: COLORS.teal,
            borderRadius: 14,
            paddingVertical: 16,
            alignItems: "center",
            opacity: canContinue ? 1 : 0.5,
          }}
        >
          <Text style={{ color: "white", fontWeight: "700", fontSize: 15 }}>Continue</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}
