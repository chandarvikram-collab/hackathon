import { View, Text, TextInput, Pressable, ScrollView, KeyboardAvoidingView, Platform } from "react-native";
import { useRouter } from "expo-router";
import { OnboardingHeader } from "@/components/OnboardingHeader";
import { ChipSelector } from "@/components/ChipSelector";
import { useOnboarding } from "@/hooks/useOnboarding";
import { CORE_SKILL_SUGGESTIONS } from "@/constants/profileOptions";
import { COLORS } from "@/constants/theme";

const inputStyle = {
  backgroundColor: "white",
  borderWidth: 1,
  borderColor: COLORS.border,
  borderRadius: 14,
  paddingHorizontal: 16,
  paddingVertical: 13,
  fontSize: 15,
  color: COLORS.navy,
} as const;

const labelStyle = {
  fontSize: 13,
  fontWeight: "600" as const,
  color: COLORS.navy,
  marginBottom: 6,
};

const hintStyle = {
  fontSize: 12,
  color: COLORS.slateLight,
  marginBottom: 8,
};

export default function OnboardingStep1() {
  const router = useRouter();
  const { draft, update } = useOnboarding();

  const canContinue =
    draft.full_name.trim().length > 0 &&
    draft.current_role.trim().length > 0 &&
    draft.industry.trim().length > 0 &&
    draft.core_skills.length > 0;

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: COLORS.canvas }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
        <OnboardingHeader
          step={1}
          title="The Basics"
          subtitle="What's your professional footprint right now?"
        />

        <View style={{ paddingHorizontal: 24, gap: 20 }}>
          <View>
            <Text style={labelStyle}>Your name</Text>
            <TextInput
              value={draft.full_name}
              onChangeText={(t) => update({ full_name: t })}
              placeholder="Jordan Lee"
              placeholderTextColor={COLORS.slateLight}
              style={inputStyle}
            />
          </View>

          <View>
            <Text style={labelStyle}>Current job title</Text>
            <TextInput
              value={draft.current_role}
              onChangeText={(t) => update({ current_role: t })}
              placeholder="Senior Product Designer"
              placeholderTextColor={COLORS.slateLight}
              style={inputStyle}
            />
          </View>

          <View>
            <Text style={labelStyle}>Industry</Text>
            <TextInput
              value={draft.industry}
              onChangeText={(t) => update({ industry: t })}
              placeholder="Fintech, Healthcare, Climate Tech…"
              placeholderTextColor={COLORS.slateLight}
              style={inputStyle}
            />
          </View>

          <View>
            <Text style={labelStyle}>The 30-second pitch</Text>
            <Text style={hintStyle}>How would you describe what you do to someone outside your field?</Text>
            <TextInput
              value={draft.pitch}
              onChangeText={(t) => update({ pitch: t })}
              placeholder="I help early-stage startups turn rough ideas into products people actually want…"
              placeholderTextColor={COLORS.slateLight}
              multiline
              numberOfLines={3}
              style={[inputStyle, { minHeight: 90, textAlignVertical: "top" }]}
            />
          </View>

          <View>
            <Text style={labelStyle}>Core skillset</Text>
            <Text style={hintStyle}>Pick your top 3–5 hard or soft skills.</Text>
            <ChipSelector
              options={CORE_SKILL_SUGGESTIONS}
              selected={draft.core_skills}
              onChange={(skills) => update({ core_skills: skills })}
              maxSelections={5}
            />
          </View>
        </View>

        <View style={{ paddingHorizontal: 24, paddingVertical: 28, marginTop: 8 }}>
          <Pressable
            onPress={() => router.push("/onboarding/step-2")}
            disabled={!canContinue}
            style={{
              backgroundColor: COLORS.teal,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              opacity: canContinue ? 1 : 0.5,
            }}
          >
            <Text style={{ color: "white", fontWeight: "700", fontSize: 15 }}>Continue</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
