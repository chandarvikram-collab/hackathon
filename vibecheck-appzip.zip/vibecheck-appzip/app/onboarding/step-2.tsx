import { View, Text, TextInput, Pressable, ScrollView, KeyboardAvoidingView, Platform } from "react-native";
import { useRouter } from "expo-router";
import { OnboardingHeader } from "@/components/OnboardingHeader";
import { useOnboarding } from "@/hooks/useOnboarding";
import { COLORS } from "@/constants/theme";

const inputStyle = {
  backgroundColor: "white",
  borderWidth: 1,
  borderColor: COLORS.border,
  borderRadius: 14,
  paddingHorizontal: 16,
  paddingVertical: 13,
  fontSize: 15,
  color: COLORS.navy,
} as const;

const labelStyle = {
  fontSize: 13,
  fontWeight: "600" as const,
  color: COLORS.navy,
  marginBottom: 6,
};

const hintStyle = {
  fontSize: 12,
  color: COLORS.slateLight,
  marginBottom: 8,
};

export default function OnboardingStep2() {
  const router = useRouter();
  const { draft, update } = useOnboarding();

  const canContinue =
    draft.next_milestone.trim().length > 0 && draft.skills_horizon.trim().length > 0;

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: COLORS.canvas }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
        <OnboardingHeader
          step={2}
          title="Growth & Ambition"
          subtitle="This is the secret sauce — it's how we pair people who can actually help each other."
        />

        <View style={{ paddingHorizontal: 24, gap: 20 }}>
          <View>
            <Text style={labelStyle}>Your next milestone</Text>
            <Text style={hintStyle}>What's your primary career goal over the next 12 months?</Text>
            <TextInput
              value={draft.next_milestone}
              onChangeText={(t) => update({ next_milestone: t })}
              placeholder="Switching into product management…"
              placeholderTextColor={COLORS.slateLight}
              multiline
              style={[inputStyle, { minHeight: 80, textAlignVertical: "top" }]}
            />
          </View>

          <View>
            <Text style={labelStyle}>Skills on the horizon</Text>
            <Text style={hintStyle}>One specific skill or tool you're actively trying to learn right now.</Text>
            <TextInput
              value={draft.skills_horizon}
              onChangeText={(t) => update({ skills_horizon: t })}
              placeholder="SQL, public speaking, Figma…"
              placeholderTextColor={COLORS.slateLight}
              style={inputStyle}
            />
          </View>

          <View>
            <Text style={labelStyle}>Industries of interest</Text>
            <Text style={hintStyle}>
              If you're looking to pivot or expand, which other industries fascinate you? (optional)
            </Text>
            <TextInput
              value={draft.industries_of_interest}
              onChangeText={(t) => update({ industries_of_interest: t })}
              placeholder="Climate tech, education, gaming…"
              placeholderTextColor={COLORS.slateLight}
              style={inputStyle}
            />
          </View>
        </View>

        <View
          style={{
            flexDirection: "row",
            gap: 12,
            paddingHorizontal: 24,
            paddingVertical: 28,
            marginTop: 8,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            style={{
              flex: 1,
              borderWidth: 1,
              borderColor: COLORS.border,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
            }}
          >
            <Text style={{ fontWeight: "700", fontSize: 15, color: COLORS.slate }}>Back</Text>
          </Pressable>
          <Pressable
            onPress={() => router.push("/onboarding/step-3")}
            disabled={!canContinue}
            style={{
              flex: 1,
              backgroundColor: COLORS.teal,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              opacity: canContinue ? 1 : 0.5,
            }}
          >
            <Text style={{ color: "white", fontWeight: "700", fontSize: 15 }}>Continue</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
