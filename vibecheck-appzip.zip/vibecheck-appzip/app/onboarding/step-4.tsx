import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import * as Location from "expo-location";
import { OnboardingHeader } from "@/components/OnboardingHeader";
import { useOnboarding } from "@/hooks/useOnboarding";
import { useAuth } from "@/hooks/useAuth";
import { useDemo } from "@/contexts/DemoContext";
import { supabase } from "@/lib/supabase";
import { COLORS } from "@/constants/theme";

const inputStyle = {
  backgroundColor: "white",
  borderWidth: 1,
  borderColor: COLORS.border,
  borderRadius: 14,
  paddingHorizontal: 16,
  paddingVertical: 13,
  fontSize: 15,
  color: COLORS.navy,
} as const;

const labelStyle = {
  fontSize: 13,
  fontWeight: "600" as const,
  color: COLORS.navy,
  marginBottom: 6,
};

const hintStyle = {
  fontSize: 12,
  color: COLORS.slateLight,
  marginBottom: 8,
};

export default function OnboardingStep4() {
  const router = useRouter();
  const { draft, update } = useOnboarding();
  const { session } = useAuth();
  const { isDemoMode } = useDemo();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canSubmit =
    draft.watercooler_topic.trim().length > 0 && draft.win_proud_of.trim().length > 0;

  async function handleSubmit() {
    if (!session) return;
    setError(null);
    setSubmitting(true);

    // In demo mode skip all Supabase / location calls and go straight to discover.
    if (isDemoMode) {
      router.replace("/(tabs)/discover");
      return;
    }

    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setError(
          "VibeCheck needs location access to show you people nearby. Please enable it in Settings."
        );
        setSubmitting(false);
        return;
      }

      const position = await Location.getCurrentPositionAsync({});

      const { error: profileError } = await supabase.from("profiles").insert({
        id: session.user.id,
        full_name: draft.full_name,
        current_role: draft.current_role,
        industry: draft.industry,
        pitch: draft.pitch || null,
        core_skills: draft.core_skills,
        collaboration_style: draft.brainstorming_style,
        brainstorming_style: draft.brainstorming_style,
        preferred_medium: draft.preferred_medium,
        ideal_connection: draft.ideal_connection,
        next_milestone: draft.next_milestone || null,
        skills_horizon: draft.skills_horizon || null,
        industries_of_interest: draft.industries_of_interest || null,
        watercooler_topic: draft.watercooler_topic || null,
        current_obsession: draft.current_obsession || null,
        win_proud_of: draft.win_proud_of || null,
      });

      if (profileError) {
        setError(profileError.message);
        setSubmitting(false);
        return;
      }

      const { error: fnError } = await supabase.functions.invoke("update_location", {
        body: { latitude: position.coords.latitude, longitude: position.coords.longitude },
      });

      if (fnError) {
        console.warn("[onboarding] update_location failed:", fnError.message);
      }

      router.replace("/(tabs)/discover");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setSubmitting(false);
    }
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={{ flex: 1, backgroundColor: COLORS.canvas }}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
        <OnboardingHeader
          step={4}
          title="Icebreakers"
          subtitle="People connect with people, not resumes. Show some personality."
        />

        <View style={{ paddingHorizontal: 24, gap: 20 }}>
          <View>
            <Text style={labelStyle}>The watercooler topic</Text>
            <Text style={hintStyle}>Something outside of work you could talk about for hours.</Text>
            <TextInput
              value={draft.watercooler_topic}
              onChangeText={(t) => update({ watercooler_topic: t })}
              placeholder="Trail running, sourdough, the NBA draft…"
              placeholderTextColor={COLORS.slateLight}
              multiline
              style={[inputStyle, { minHeight: 70, textAlignVertical: "top" }]}
            />
          </View>

          <View>
            <Text style={labelStyle}>Current obsession</Text>
            <Text style={hintStyle}>
              A book, article, podcast, or creator that changed how you think. (optional)
            </Text>
            <TextInput
              value={draft.current_obsession}
              onChangeText={(t) => update({ current_obsession: t })}
              placeholder="…"
              placeholderTextColor={COLORS.slateLight}
              multiline
              style={[inputStyle, { minHeight: 70, textAlignVertical: "top" }]}
            />
          </View>

          <View>
            <Text style={labelStyle}>A win you're proud of</Text>
            <Text style={hintStyle}>A recent professional project or personal milestone you celebrated.</Text>
            <TextInput
              value={draft.win_proud_of}
              onChangeText={(t) => update({ win_proud_of: t })}
              placeholder="…"
              placeholderTextColor={COLORS.slateLight}
              multiline
              style={[inputStyle, { minHeight: 70, textAlignVertical: "top" }]}
            />
          </View>
        </View>

        {error && (
          <Text style={{ fontSize: 13, color: COLORS.danger, paddingHorizontal: 24, marginTop: 16 }}>
            {error}
          </Text>
        )}

        <View
          style={{
            flexDirection: "row",
            gap: 12,
            paddingHorizontal: 24,
            paddingVertical: 28,
            marginTop: 8,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            disabled={submitting}
            style={{
              flex: 1,
              borderWidth: 1,
              borderColor: COLORS.border,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
            }}
          >
            <Text style={{ fontWeight: "700", fontSize: 15, color: COLORS.slate }}>Back</Text>
          </Pressable>
          <Pressable
            onPress={handleSubmit}
            disabled={!canSubmit || submitting}
            style={{
              flex: 1,
              backgroundColor: COLORS.teal,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              opacity: canSubmit && !submitting ? 1 : 0.5,
            }}
          >
            {submitting ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text style={{ color: "white", fontWeight: "700", fontSize: 15 }}>Finish</Text>
            )}
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
