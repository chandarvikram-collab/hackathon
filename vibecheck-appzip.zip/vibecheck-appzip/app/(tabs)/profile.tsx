import { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Switch,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabase";
import { OwnProfile } from "@/types/profile";
import { useDemo } from "@/contexts/DemoContext";
import { DEMO_OWN_PROFILE } from "@/demo/profiles";
import { COLORS } from "@/constants/theme";

function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={{ marginBottom: 24 }}>
      <Text
        style={{
          fontSize: 11,
          fontWeight: "700",
          textTransform: "uppercase",
          letterSpacing: 1,
          color: COLORS.slateLight,
          marginBottom: 10,
        }}
      >
        {label}
      </Text>
      {children}
    </View>
  );
}

export default function MyProfileScreen() {
  const { session, signOut } = useAuth();
  const { isDemoMode } = useDemo();
  const [profile, setProfile] = useState<OwnProfile | null>(isDemoMode ? DEMO_OWN_PROFILE : null);
  const [loading, setLoading] = useState(!isDemoMode);
  const [updatingDiscoverable, setUpdatingDiscoverable] = useState(false);

  useEffect(() => {
    if (isDemoMode || !session) return;
    supabase
      .from("profiles")
      .select("*")
      .eq("id", session.user.id)
      .single()
      .then(({ data }) => {
        setProfile(data as OwnProfile);
        setLoading(false);
      });
  }, [session, isDemoMode]);

  async function toggleDiscoverable(value: boolean) {
    if (!profile || !session) return;
    setUpdatingDiscoverable(true);
    if (isDemoMode) {
      setProfile({ ...profile, discoverable: value });
      setUpdatingDiscoverable(false);
      return;
    }
    const { error } = await supabase
      .from("profiles")
      .update({ discoverable: value })
      .eq("id", session.user.id);
    if (!error) setProfile({ ...profile, discoverable: value });
    setUpdatingDiscoverable(false);
  }

  if (loading) {
    return (
      <SafeAreaView
        style={{ flex: 1, backgroundColor: COLORS.canvas, justifyContent: "center" }}
      >
        <ActivityIndicator size="large" color={COLORS.teal} />
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView
        style={{ flex: 1, backgroundColor: COLORS.canvas, justifyContent: "center", padding: 24 }}
      >
        <Text style={{ color: COLORS.danger, textAlign: "center" }}>
          Couldn't load your profile.
        </Text>
      </SafeAreaView>
    );
  }

  const initials = profile.full_name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.canvas }} edges={["top"]}>
      <ScrollView contentContainerStyle={{ paddingBottom: 60 }}>
        {/* Demo banner */}
        {isDemoMode && (
          <View
            style={{
              backgroundColor: "#FEF3C7",
              paddingVertical: 10,
              paddingHorizontal: 20,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 13, color: "#92400E", flex: 1 }}>
              ✦ Demo mode — data is local and won't be saved
            </Text>
          </View>
        )}

        {/* Avatar + name */}
        <View style={{ alignItems: "center", paddingTop: 32, paddingBottom: 24 }}>
          <View
            style={{
              width: 88,
              height: 88,
              borderRadius: 44,
              backgroundColor: COLORS.teal,
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 14,
            }}
          >
            <Text style={{ fontSize: 32, fontWeight: "800", color: "white" }}>{initials}</Text>
          </View>
          <Text style={{ fontSize: 22, fontWeight: "800", color: COLORS.navy }}>{profile.full_name}</Text>
          <Text style={{ fontSize: 14, color: COLORS.slate, marginTop: 4 }}>
            {profile.current_role} · {profile.industry}
          </Text>
        </View>

        <View style={{ paddingHorizontal: 24 }}>
          {/* Discoverable toggle */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: "white",
              borderWidth: 1,
              borderColor: COLORS.border,
              borderRadius: 16,
              padding: 16,
              marginBottom: 28,
            }}
          >
            <View style={{ flex: 1, paddingRight: 12 }}>
              <Text style={{ fontSize: 14, fontWeight: "700", color: COLORS.navy }}>
                Discoverable
              </Text>
              <Text style={{ fontSize: 12, color: COLORS.slateLight, marginTop: 3 }}>
                When off, you won't appear to anyone nearby.
              </Text>
            </View>
            {updatingDiscoverable ? (
              <ActivityIndicator color={COLORS.teal} />
            ) : (
              <Switch
                value={profile.discoverable}
                onValueChange={toggleDiscoverable}
                trackColor={{ true: COLORS.teal, false: COLORS.border }}
                thumbColor="white"
              />
            )}
          </View>

          {/* Skills */}
          <Section label="Skills">
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {profile.core_skills.map((skill) => (
                <View
                  key={skill}
                  style={{
                    backgroundColor: COLORS.tealBlur,
                    borderRadius: 99,
                    paddingHorizontal: 14,
                    paddingVertical: 7,
                  }}
                >
                  <Text style={{ fontSize: 13, fontWeight: "600", color: COLORS.teal }}>
                    {skill}
                  </Text>
                </View>
              ))}
            </View>
          </Section>

          {/* Pitch */}
          {profile.pitch && (
            <Section label="Pitch">
              <View
                style={{
                  backgroundColor: "white",
                  borderWidth: 1,
                  borderColor: COLORS.border,
                  borderRadius: 14,
                  padding: 16,
                }}
              >
                <Text style={{ fontSize: 14, color: COLORS.navy, fontStyle: "italic", lineHeight: 22 }}>
                  "{profile.pitch}"
                </Text>
              </View>
            </Section>
          )}

          {/* Icebreakers */}
          {(profile.watercooler_topic || profile.win_proud_of || profile.current_obsession) && (
            <Section label="Icebreakers">
              <View style={{ gap: 10 }}>
                {profile.watercooler_topic && (
                  <View
                    style={{
                      backgroundColor: "white",
                      borderWidth: 1,
                      borderColor: COLORS.border,
                      borderRadius: 14,
                      padding: 14,
                      borderLeftWidth: 3,
                      borderLeftColor: COLORS.teal,
                    }}
                  >
                    <Text style={{ fontSize: 11, fontWeight: "700", color: COLORS.slateLight, marginBottom: 4 }}>
                      WATERCOOLER
                    </Text>
                    <Text style={{ fontSize: 14, color: COLORS.navy }}>{profile.watercooler_topic}</Text>
                  </View>
                )}
                {profile.current_obsession && (
                  <View
                    style={{
                      backgroundColor: "white",
                      borderWidth: 1,
                      borderColor: COLORS.border,
                      borderRadius: 14,
                      padding: 14,
                      borderLeftWidth: 3,
                      borderLeftColor: COLORS.purple,
                    }}
                  >
                    <Text style={{ fontSize: 11, fontWeight: "700", color: COLORS.slateLight, marginBottom: 4 }}>
                      CURRENT OBSESSION
                    </Text>
                    <Text style={{ fontSize: 14, color: COLORS.navy }}>{profile.current_obsession}</Text>
                  </View>
                )}
                {profile.win_proud_of && (
                  <View
                    style={{
                      backgroundColor: "white",
                      borderWidth: 1,
                      borderColor: COLORS.border,
                      borderRadius: 14,
                      padding: 14,
                      borderLeftWidth: 3,
                      borderLeftColor: COLORS.amber,
                    }}
                  >
                    <Text style={{ fontSize: 11, fontWeight: "700", color: COLORS.slateLight, marginBottom: 4 }}>
                      A WIN I'M PROUD OF
                    </Text>
                    <Text style={{ fontSize: 14, color: COLORS.navy }}>{profile.win_proud_of}</Text>
                  </View>
                )}
              </View>
            </Section>
          )}

          {/* Sign Out */}
          <Pressable
            onPress={signOut}
            style={{
              borderWidth: 1.5,
              borderColor: COLORS.danger,
              borderRadius: 14,
              paddingVertical: 16,
              alignItems: "center",
              marginTop: 8,
            }}
          >
            <Text style={{ fontWeight: "700", fontSize: 15, color: COLORS.danger }}>
              {isDemoMode ? "Exit Demo" : "Sign Out"}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
