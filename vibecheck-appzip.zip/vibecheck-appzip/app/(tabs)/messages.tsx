import { useEffect, useState, useCallback } from "react";
import { View, Text, FlatList, ActivityIndicator, Pressable, RefreshControl } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabase";
import { useDemo } from "@/contexts/DemoContext";
import { MOCK_PROFILES } from "@/demo/profiles";
import { COLORS } from "@/constants/theme";

interface ConnectedPeer {
  connectionId: string;
  peerId: string;
  peerName: string;
  peerRole: string;
}

function PeerRow({ peer }: { peer: ConnectedPeer }) {
  const initials = peer.peerName
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <Pressable
      style={{
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "white",
        borderWidth: 1,
        borderColor: COLORS.border,
        borderRadius: 16,
        padding: 16,
        marginBottom: 10,
      }}
    >
      <View
        style={{
          width: 48,
          height: 48,
          borderRadius: 24,
          backgroundColor: COLORS.tealBlur,
          alignItems: "center",
          justifyContent: "center",
          marginRight: 14,
        }}
      >
        <Text style={{ fontSize: 15, fontWeight: "800", color: COLORS.teal }}>{initials}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 15, fontWeight: "700", color: COLORS.navy }}>{peer.peerName}</Text>
        <Text style={{ fontSize: 13, color: COLORS.slate, marginTop: 2 }}>{peer.peerRole}</Text>
      </View>
      <View
        style={{
          backgroundColor: COLORS.tealBlur,
          borderRadius: 99,
          paddingHorizontal: 12,
          paddingVertical: 6,
        }}
      >
        <Text style={{ fontSize: 12, fontWeight: "600", color: COLORS.teal }}>Message</Text>
      </View>
    </Pressable>
  );
}

export default function MessagesScreen() {
  const { session } = useAuth();
  const { isDemoMode, demoConnections } = useDemo();
  const [peers, setPeers] = useState<ConnectedPeer[]>([]);
  const [loading, setLoading] = useState(true);

  // ── Build the peers list ─────────────────────────────────────────────────
  const loadConnections = useCallback(async () => {
    setLoading(true);

    if (isDemoMode) {
      const accepted = demoConnections.filter((c) => c.status === "accepted");
      const resolved: ConnectedPeer[] = accepted.map((c) => {
        const peerId =
          c.requester_id === session?.user.id ? c.recipient_id : c.requester_id;
        const profile = MOCK_PROFILES.find((p) => p.id === peerId);
        return {
          connectionId: c.id,
          peerId,
          peerName: profile?.full_name ?? "VibeCheck User",
          peerRole: profile?.current_role ?? "",
        };
      });
      setPeers(resolved);
      setLoading(false);
      return;
    }

    if (!session) {
      setLoading(false);
      return;
    }
    const userId = session.user.id;

    const { data: connections } = await supabase
      .from("connections")
      .select("id, requester_id, recipient_id")
      .eq("status", "accepted")
      .or(`requester_id.eq.${userId},recipient_id.eq.${userId}`);

    if (!connections || connections.length === 0) {
      setPeers([]);
      setLoading(false);
      return;
    }

    const peerIds = connections.map((c) =>
      c.requester_id === userId ? c.recipient_id : c.requester_id
    );

    const { data: profiles } = await supabase
      .from("public_profiles")
      .select("id, full_name, current_role")
      .in("id", peerIds);

    const profileById = new Map(
      (profiles ?? []).map((p) => [p.id, p])
    );

    setPeers(
      connections.map((c) => {
        const peerId = c.requester_id === userId ? c.recipient_id : c.requester_id;
        const p = profileById.get(peerId);
        return {
          connectionId: c.id,
          peerId,
          peerName: p?.full_name ?? "VibeCheck User",
          peerRole: p?.current_role ?? "",
        };
      })
    );
    setLoading(false);
  }, [session, isDemoMode, demoConnections]);

  useEffect(() => {
    loadConnections();
  }, [loadConnections]);

  if (loading) {
    return (
      <SafeAreaView
        style={{ flex: 1, backgroundColor: COLORS.canvas, justifyContent: "center" }}
      >
        <ActivityIndicator size="large" color={COLORS.teal} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.canvas }} edges={["top"]}>
      <View style={{ paddingHorizontal: 24, paddingTop: 20, paddingBottom: 8 }}>
        <Text style={{ fontSize: 28, fontWeight: "800", color: COLORS.navy }}>Messages</Text>
        <Text style={{ fontSize: 14, color: COLORS.slate, marginTop: 4 }}>
          {peers.length > 0
            ? `${peers.length} connection${peers.length > 1 ? "s" : ""}`
            : "No connections yet"}
        </Text>
      </View>

      <FlatList
        data={peers}
        keyExtractor={(item) => item.connectionId}
        contentContainerStyle={{ padding: 20, paddingTop: 8, paddingBottom: 40, flexGrow: 1 }}
        refreshControl={
          <RefreshControl refreshing={loading} onRefresh={loadConnections} tintColor={COLORS.teal} />
        }
        ListEmptyComponent={
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 80, paddingHorizontal: 32 }}>
            <View
              style={{
                width: 72,
                height: 72,
                borderRadius: 36,
                backgroundColor: COLORS.tealBlur,
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 20,
              }}
            >
              <Text style={{ fontSize: 32 }}>💬</Text>
            </View>
            <Text style={{ fontSize: 17, fontWeight: "700", color: COLORS.navy, textAlign: "center", marginBottom: 8 }}>
              No conversations yet
            </Text>
            <Text style={{ fontSize: 14, color: COLORS.slateLight, textAlign: "center", lineHeight: 22 }}>
              Connect with someone from the Discover tab — once they accept, you'll chat here.
            </Text>
          </View>
        }
        renderItem={({ item }) => <PeerRow peer={item} />}
      />
    </SafeAreaView>
  );
}
