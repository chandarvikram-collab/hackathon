import { useRef, useState, useCallback } from "react";
import {
  View,
  Text,
  Pressable,
  FlatList,
  ActivityIndicator,
  RefreshControl,
  Platform,
} from "react-native";
import BottomSheet from "@gorhom/bottom-sheet";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "@/hooks/useAuth";
import { useNearbyProfiles } from "@/hooks/useNearbyProfiles";
import { ProfileDrawer } from "@/components/ProfileDrawer";
import { ProximityCard } from "@/components/ProximityCard";
// NearbyMap is platform-split: NearbyMap.native.tsx on iOS/Android,
// NearbyMap.web.tsx on web — react-native-maps never enters the web bundle.
import { NearbyMap } from "@/components/NearbyMap";
import { PublicProfile } from "@/types/profile";
import { haversineMeters, bucketDistance } from "@/lib/geo";
import { bandLabel } from "@/types/profile";
import { useDemo } from "@/contexts/DemoContext";
import { DEMO_OWN_PROFILE } from "@/demo/profiles";
import { COLORS } from "@/constants/theme";

type ViewMode = "map" | "list";

export default function DiscoverScreen() {
  const { session } = useAuth();
  const { isDemoMode } = useDemo();
  const { profiles, loading, error, refresh } = useNearbyProfiles(session?.user.id);
  const [viewMode, setViewMode] = useState<ViewMode>(Platform.OS === "web" ? "list" : "map");
  const [selectedProfile, setSelectedProfile] = useState<PublicProfile | null>(null);
  const sheetRef = useRef<BottomSheet>(null);

  const handleSelectProfile = useCallback((profile: PublicProfile) => {
    setSelectedProfile(profile);
    sheetRef.current?.snapToIndex(0);
  }, []);

  function distanceLabelFor(profile: PublicProfile): string {
    // In demo mode use the demo viewer's approx location as the center.
    const centerLat = isDemoMode
      ? DEMO_OWN_PROFILE.approx_latitude
      : 37.3382;
    const centerLon = isDemoMode
      ? DEMO_OWN_PROFILE.approx_longitude
      : -121.8863;
    const meters = haversineMeters(
      centerLat,
      centerLon,
      profile.approx_latitude,
      profile.approx_longitude
    );
    return bandLabel(bucketDistance(meters));
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.canvas }} edges={["top"]}>
      {/* Header */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 20,
          paddingTop: 8,
          paddingBottom: 12,
        }}
      >
        {/* View toggle */}
        <View
          style={{
            flexDirection: "row",
            backgroundColor: COLORS.border,
            borderRadius: 99,
            padding: 4,
          }}
        >
          {(["map", "list"] as ViewMode[]).map((mode) => (
            <Pressable
              key={mode}
              onPress={() => setViewMode(mode)}
              style={{
                paddingHorizontal: 18,
                paddingVertical: 8,
                borderRadius: 99,
                backgroundColor: viewMode === mode ? "white" : "transparent",
              }}
            >
              <Text
                style={{
                  fontSize: 13,
                  fontWeight: "700",
                  color: viewMode === mode ? COLORS.navy : COLORS.slate,
                }}
              >
                {mode === "map" ? "Map" : "List"}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Filter button */}
        <Pressable
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            backgroundColor: "white",
            borderWidth: 1,
            borderColor: COLORS.border,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text style={{ fontSize: 16 }}>⚙️</Text>
        </Pressable>
      </View>

      {/* Demo notice */}
      {isDemoMode && (
        <View
          style={{
            marginHorizontal: 20,
            marginBottom: 8,
            backgroundColor: "#EFF6FF",
            borderRadius: 10,
            paddingHorizontal: 14,
            paddingVertical: 8,
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <Text style={{ fontSize: 12, color: "#1E40AF" }}>
            ✦ Demo mode · {profiles.length} sample profiles nearby
          </Text>
        </View>
      )}

      {/* Loading */}
      {loading && (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator size="large" color={COLORS.teal} />
          <Text style={{ color: COLORS.slateLight, marginTop: 12, fontSize: 14 }}>
            Finding people nearby…
          </Text>
        </View>
      )}

      {/* Error */}
      {!loading && error && (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 32 }}>
          <Text style={{ color: COLORS.danger, textAlign: "center" }}>
            Couldn't load nearby people: {error}
          </Text>
        </View>
      )}

      {/* Map view */}
      {!loading && !error && viewMode === "map" && (
        <NearbyMap profiles={profiles} onSelectProfile={handleSelectProfile} />
      )}

      {/* List view */}
      {!loading && !error && viewMode === "list" && (
        <FlatList
          data={profiles}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 20, paddingBottom: 40 }}
          refreshControl={
            <RefreshControl
              refreshing={loading}
              onRefresh={refresh}
              tintColor={COLORS.teal}
            />
          }
          ListEmptyComponent={
            <View style={{ alignItems: "center", paddingVertical: 80 }}>
              <Text style={{ fontSize: 40, marginBottom: 16 }}>📍</Text>
              <Text style={{ fontSize: 16, fontWeight: "700", color: COLORS.navy, marginBottom: 8 }}>
                No one nearby right now
              </Text>
              <Text style={{ fontSize: 14, color: COLORS.slateLight, textAlign: "center" }}>
                Check back later or try expanding your radius.
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <ProximityCard
              profile={item}
              distanceLabel={distanceLabelFor(item)}
              onPress={() => handleSelectProfile(item)}
            />
          )}
        />
      )}

      <ProfileDrawer ref={sheetRef} profile={selectedProfile} viewerId={session?.user.id} />
    </SafeAreaView>
  );
}
