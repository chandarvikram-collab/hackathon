import "../global.css";
import { useEffect, useState } from "react";
import { Stack, useRouter, useSegments } from "expo-router";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { StatusBar } from "expo-status-bar";
import { View, ActivityIndicator } from "react-native";
import { DemoProvider } from "@/contexts/DemoContext";
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabase";
import { useDemo } from "@/contexts/DemoContext";
import { COLORS } from "@/constants/theme";

function RootNavigation() {
  const { session, initializing } = useAuth();
  const { isDemoMode } = useDemo();
  const segments = useSegments();
  const router = useRouter();
  const [checkingProfile, setCheckingProfile] = useState(true);
  const [hasProfile, setHasProfile] = useState(false);

  useEffect(() => {
    // Demo mode: always treat the demo user as having a complete profile.
    if (isDemoMode) {
      setHasProfile(true);
      setCheckingProfile(false);
      return;
    }

    if (!session) {
      setCheckingProfile(false);
      return;
    }

    supabase
      .from("profiles")
      .select("id")
      .eq("id", session.user.id)
      .maybeSingle()
      .then(({ data, error }) => {
        // On transient error, assume profile exists to avoid incorrectly
        // redirecting an existing user back through onboarding.
        setHasProfile(error ? true : !!data);
        setCheckingProfile(false);
      });
  }, [session, isDemoMode]);

  useEffect(() => {
    if (initializing || checkingProfile) return;

    const inAuthGroup = segments[0] === "(auth)";
    const inOnboarding = segments[0] === "onboarding";

    if (!session && !inAuthGroup) {
      router.replace("/(auth)/sign-in");
    } else if (session && !hasProfile && !inOnboarding) {
      router.replace("/onboarding/step-1");
    } else if (session && hasProfile && (inAuthGroup || inOnboarding)) {
      router.replace("/(tabs)/discover");
    }
  }, [initializing, checkingProfile, session, hasProfile, segments]);

  if (initializing || checkingProfile) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: COLORS.canvas,
        }}
      >
        <ActivityIndicator size="large" color={COLORS.teal} />
      </View>
    );
  }

  return <Stack screenOptions={{ headerShown: false }} />;
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <DemoProvider>
        <AuthProvider>
          <StatusBar style="dark" />
          <RootNavigation />
        </AuthProvider>
      </DemoProvider>
    </GestureHandlerRootView>
  );
}
