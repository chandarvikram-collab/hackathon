-- get_match_score(viewer_id, target_id) -> integer percentage
--
-- Implements the VibeMatch formula from PRD 4.2:
--   Score = 0.40 * skills + 0.35 * collaboration + 0.25 * medium
--
-- SECURITY DEFINER so it can read both profiles' full rows internally,
-- but it returns ONLY the integer score -- never any profile field --
-- closing the client-side scoring gap flagged in PRD 4.2/4.4.
--
-- Grant EXECUTE to `authenticated` only; do not grant on the underlying
-- `profiles` table directly to those callers.

create or replace function public.get_match_score(viewer_id uuid, target_id uuid)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v record;
  t record;
  v_found boolean;
  t_found boolean;
  skills_score numeric := 0;
  collab_score numeric := 0;
  medium_score numeric := 0;
  total numeric := 0;
  a_to_b boolean;
  b_to_a boolean;
  direct_overlap boolean;
begin
  select core_skills, skills_horizon, ideal_connection, preferred_medium
    into v
    from public.profiles where id = viewer_id;
  v_found := found;

  select core_skills, skills_horizon, ideal_connection, preferred_medium
    into t
    from public.profiles where id = target_id;
  t_found := found;

  if not v_found or not t_found then
    return 0;
  end if;

  -- Skills: does target want something viewer has, and/or vice versa,
  -- plus partial credit for direct overlap in core_skills.
  a_to_b := exists (
    select 1 from unnest(v.core_skills) s
    where position(lower(s) in lower(coalesce(t.skills_horizon, ''))) > 0
  );
  b_to_a := exists (
    select 1 from unnest(t.core_skills) s
    where position(lower(s) in lower(coalesce(v.skills_horizon, ''))) > 0
  );
  direct_overlap := exists (
    select 1 from unnest(v.core_skills) vs
    join unnest(t.core_skills) ts on lower(vs) = lower(ts)
  );

  skills_score := 0;
  if a_to_b then skills_score := skills_score + 0.45; end if;
  if b_to_a then skills_score := skills_score + 0.45; end if;
  if direct_overlap then skills_score := skills_score + 0.10; end if;
  skills_score := least(skills_score, 1.0);

  -- Collaboration style: exact match or known complementary pairing.
  if v.ideal_connection = t.ideal_connection then
    collab_score := 1.0;
  elsif (v.ideal_connection = 'mentors' and t.ideal_connection = 'mentees')
     or (v.ideal_connection = 'mentees' and t.ideal_connection = 'mentors') then
    collab_score := 1.0;
  else
    collab_score := 0.2;
  end if;

  -- Preferred medium: exact match, partial credit otherwise.
  if v.preferred_medium = t.preferred_medium then
    medium_score := 1.0;
  else
    medium_score := 0.15;
  end if;

  total := (0.40 * skills_score) + (0.35 * collab_score) + (0.25 * medium_score);

  return round(total * 100)::integer;
end;
$$;

revoke all on function public.get_match_score(uuid, uuid) from public;
grant execute on function public.get_match_score(uuid, uuid) to authenticated;
