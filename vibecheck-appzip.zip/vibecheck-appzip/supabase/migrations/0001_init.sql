-- VibeCheck initial schema
-- Matches PRD Section 4.1, with the location-privacy fix from PRD 4.3
-- (exact_* columns, randomized approx_* offset, public_profiles view that
-- structurally excludes exact_* from anything the client can query).

create extension if not exists "uuid-ossp";

-- ---------------------------------------------------------------------
-- profiles
-- ---------------------------------------------------------------------
create table public.profiles (
    id uuid references auth.users not null primary key,
    updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
    full_name text not null,
    current_role text not null,
    industry text not null,
    pitch text,

    -- Section 1 & 3 — structured fields for fast matching
    core_skills text[] default '{}'::text[],
    collaboration_style text not null default '',
    brainstorming_style text not null default '',
    preferred_medium text not null default '',
    ideal_connection text not null default '',

    -- Section 2 & 4 — open text, shown verbatim in the profile drawer
    next_milestone text,
    skills_horizon text,
    industries_of_interest text,
    watercooler_topic text,
    current_obsession text,
    win_proud_of text,

    -- TRUE exact location. Never selected by the public_profiles view,
    -- never returned to any client, written only by the
    -- `update_location` edge function using the user's own JWT.
    exact_latitude numeric(9, 6),
    exact_longitude numeric(9, 6),

    -- Randomized-offset location actually served to other users (PRD 4.3).
    -- Recomputed periodically server-side — never trust a client-submitted
    -- value for these two columns.
    approx_latitude numeric(9, 6),
    approx_longitude numeric(9, 6),
    approx_radius_m integer default 400,

    last_seen timestamp with time zone default timezone('utc'::text, now()) not null,
    discoverable boolean default true not null,

    avatar_url text
);

comment on column public.profiles.exact_latitude is
  'Never expose via API. Excluded from public_profiles view by construction.';
comment on column public.profiles.exact_longitude is
  'Never expose via API. Excluded from public_profiles view by construction.';

-- ---------------------------------------------------------------------
-- connections
-- ---------------------------------------------------------------------
create table public.connections (
    id uuid default uuid_generate_v4() primary key,
    requester_id uuid references public.profiles(id) not null,
    recipient_id uuid references public.profiles(id) not null,
    status text not null default 'pending' check (status in ('pending', 'accepted', 'declined')),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    unique (requester_id, recipient_id),
    check (requester_id <> recipient_id)
);

-- ---------------------------------------------------------------------
-- public_profiles view — the ONLY thing other users' clients query
-- ---------------------------------------------------------------------
create view public.public_profiles as
  select
    id, full_name, current_role, industry, pitch, core_skills,
    collaboration_style, brainstorming_style, preferred_medium,
    ideal_connection, next_milestone, skills_horizon,
    industries_of_interest, watercooler_topic, current_obsession,
    win_proud_of, approx_latitude, approx_longitude, approx_radius_m,
    last_seen, discoverable, avatar_url
  from public.profiles
  where discoverable = true;

-- IMPORTANT: this view intentionally relies on Postgres's default view
-- security model (security_invoker = false), where the view runs with the
-- privileges of its OWNER, not the querying user. That's what lets any
-- authenticated user discover OTHER people's rows through this view even
-- though the underlying `profiles` RLS policies only allow auth.uid() = id.
-- Do NOT add `with (security_invoker = true)` to this view — doing so
-- would make it re-apply the caller's own RLS and break discovery entirely
-- (everyone would only ever see their own profile in the feed).

-- ---------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.connections enable row level security;

-- Users can only read/write their OWN full row (including exact_* fields).
create policy "Individuals can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Individuals can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Individuals can insert own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

-- Nobody gets direct SELECT on profiles for other rows — discovery goes
-- through the public_profiles view instead, which Postgres evaluates
-- against this same RLS, but only after exact_* columns are already gone
-- from the view definition.
grant select on public.public_profiles to authenticated;

create policy "Connections visible to participants"
  on public.connections for select
  using (auth.uid() = requester_id or auth.uid() = recipient_id);

create policy "Requester can create connection"
  on public.connections for insert
  with check (auth.uid() = requester_id);

create policy "Recipient can update connection status"
  on public.connections for update
  using (auth.uid() = recipient_id)
  with check (status in ('accepted', 'declined'));

-- ---------------------------------------------------------------------
-- TODO before production: enable PostGIS and replace approx_latitude /
-- approx_longitude with a `geography(Point, 4326)` column plus a
-- ST_DWithin-based query in useNearbyProfiles, instead of the flat
-- `.limit(50)` placeholder in the client. NUMERIC lat/lng works fine for
-- an MVP build but doesn't scale past a few thousand profiles per query.
-- ---------------------------------------------------------------------
