// supabase/functions/update_location/index.ts
//
// Deploy with: supabase functions deploy update_location
//
// The client sends ONLY its exact coordinate, over HTTPS, authenticated
// with the user's own JWT. This function — not the client — computes the
// randomized approx_* offset (PRD 4.3) and writes both columns using the
// service role key, which never leaves this server-side function.
//
// The client must NEVER compute or store the offset itself; doing so
// would mean the "true" exact location momentarily exists in client
// memory/logs in a context where it could leak, and would let a modified
// client lie about its own offset.

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.43.0";

const MIN_OFFSET_M = 100;
const MAX_OFFSET_M = 500;

function randomOffset(lat: number, lon: number) {
  const distance = MIN_OFFSET_M + Math.random() * (MAX_OFFSET_M - MIN_OFFSET_M);
  const bearing = Math.random() * 2 * Math.PI;
  const R = 6371000;

  const latRad = (lat * Math.PI) / 180;
  const lonRad = (lon * Math.PI) / 180;

  const newLatRad = Math.asin(
    Math.sin(latRad) * Math.cos(distance / R) +
      Math.cos(latRad) * Math.sin(distance / R) * Math.cos(bearing)
  );
  const newLonRad =
    lonRad +
    Math.atan2(
      Math.sin(bearing) * Math.sin(distance / R) * Math.cos(latRad),
      Math.cos(distance / R) - Math.sin(latRad) * Math.sin(newLatRad)
    );

  return {
    lat: (newLatRad * 180) / Math.PI,
    lon: (newLonRad * 180) / Math.PI,
  };
}

serve(async (req) => {
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing Authorization header" }), { status: 401 });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Verify the caller's JWT using the anon client first.
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401 });
    }

    const { latitude, longitude } = await req.json();
    if (typeof latitude !== "number" || typeof longitude !== "number") {
      return new Response(JSON.stringify({ error: "latitude/longitude must be numbers" }), { status: 400 });
    }
    if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
      return new Response(JSON.stringify({ error: "latitude/longitude out of range" }), { status: 400 });
    }

    const offset = randomOffset(latitude, longitude);

    // Service-role client bypasses RLS — this function is the ONLY writer
    // of exact_*/approx_* columns. Clients never write these directly.
    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { error: updateError } = await adminClient
      .from("profiles")
      .update({
        exact_latitude: latitude,
        exact_longitude: longitude,
        approx_latitude: offset.lat,
        approx_longitude: offset.lon,
        last_seen: new Date().toISOString(),
      })
      .eq("id", userData.user.id);

    if (updateError) {
      return new Response(JSON.stringify({ error: updateError.message }), { status: 500 });
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});
