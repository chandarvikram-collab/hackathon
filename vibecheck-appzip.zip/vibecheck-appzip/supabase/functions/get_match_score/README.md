# get_match_score

This is implemented as a Postgres function rather than an Edge Function —
see `supabase/migrations/0002_match_score.sql`.

A SQL function (called via `supabase.rpc(...)`) is the right tool here
because the scoring logic only needs to read two rows from the same
database and return a number; there's no external API call or heavy
compute that would justify the extra network hop of an Edge Function.

This empty directory is kept as a placeholder in case match scoring
grows complex enough (e.g. ML-based ranking) to warrant moving to a real
Edge Function later.
