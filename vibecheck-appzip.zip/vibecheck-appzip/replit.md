# VibeCheck

Proximity-based professional & social networking mobile app built with React Native (Expo Router) and Supabase.

## Project Overview

VibeCheck lets you discover and connect with professional peers nearby. Location privacy is a core feature — exact GPS coordinates never leave the device except over HTTPS to a Supabase Edge Function, which computes a randomised 100–500m offset server-side. Other users only ever see the approximate area.

Key features:
- Email/password auth via Supabase Auth
- 4-step onboarding wizard (Basics, Growth & Ambition, Collaboration Style, Icebreakers)
- Discovery screen — Map view (translucent teal proximity circles) and List view
- Profile Drawer with animated VibeMatch Bar (score computed server-side via Postgres RPC)
- Connections — send/accept/decline requests
- Messages tab listing accepted connections

## Tech Stack

- **Frontend**: React Native 0.74 + Expo ~51 + Expo Router ~3.5
- **Styling**: NativeWind v2 (Tailwind CSS for React Native)
- **Backend**: Supabase (Auth, Postgres, Edge Functions)
- **Animations**: react-native-reanimated ~3.10

## Running the App

### 1. Set up Supabase environment variables

Add these to Replit Secrets (or `.env`):

```
EXPO_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT-REF.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-public-key
```

### 2. Run the database migrations

In Supabase SQL Editor, run in order:
1. `supabase/migrations/0001_init.sql`
2. `supabase/migrations/0002_match_score.sql`

### 3. Deploy the Edge Function

```bash
supabase functions deploy update_location
```

### 4. Start

The **VibeCheck** workflow runs `npx expo start --web --port 5000`.

## Project Structure

```
app/                      Expo Router screens
  (auth)/                 sign-in, sign-up
  onboarding/             step-1 .. step-4
  (tabs)/                 discover, messages, profile
  _layout.tsx             root layout with auth/profile routing
src/
  components/             ChipSelector, VibeMatchBar, ProfileDrawer, ProximityCard
  hooks/                  useAuth, useNearbyProfiles, useMatchScore, useConnection, useOnboarding
  lib/                    supabase client, geo helpers, match score reference
  constants/              design tokens (theme.ts) and onboarding option lists
  types/                  profile.ts — mirrors the DB schema
supabase/
  migrations/             SQL — run against your Supabase project
  functions/
    update_location/      Edge Function — sole writer of exact/approx location columns
```

## User Preferences

- Keep exact_latitude / exact_longitude out of all client-side TypeScript types — privacy by design.
- Match scoring is always server-side (Postgres RPC `get_match_score`), never computed in client JS.
- Design tokens are in `src/constants/theme.ts` — do not hardcode hex values elsewhere.
